# online-store — NestJS REST API (ПР4, варіант 1: /gadgets)

CRUD для ресурсу `gadgets` (in-memory), DTO-класи, `NotFoundException`, query-фільтрація (`search`, `limit`), заголовки `X-API-Version`, `X-Service-Status`.

```bash
npm install --legacy-peer-deps
npm run start:dev      # http://localhost:3000
```
Запити для перевірки: `requests.http` (VS Code REST Client) — або curl, див. звіт.
