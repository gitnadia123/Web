export interface Gadget {
  id: string;
  title: string;
  price: number;
  warrantyMonths: number;
  cpu: string;
  ramGb: number;
}
