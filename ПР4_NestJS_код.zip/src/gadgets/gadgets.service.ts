import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import type { Gadget } from './entities/gadget.entity.js';

@Injectable()
export class GadgetsService {
  // in-memory сховище з початковими тестовими записами
  private items: Gadget[] = [
    { id: '1', title: 'Ноутбук Pro 16', price: 45000, warrantyMonths: 24, cpu: 'M3 Max', ramGb: 36 },
    { id: '2', title: 'Бездротова миша', price: 1200, warrantyMonths: 12, cpu: 'n/a', ramGb: 0 },
    { id: '3', title: 'Смартфон Nova X', price: 22000, warrantyMonths: 18, cpu: 'Snapdragon 8', ramGb: 12 },
  ];

  findAll(search?: string, limit?: string): Gadget[] {
    let result = this.items;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((g) => g.title.toLowerCase().includes(q));
    }
    if (limit !== undefined) {
      const n = Number(limit);
      if (!Number.isInteger(n) || n < 1) {
        throw new BadRequestException('Параметр limit має бути додатним цілим числом');
      }
      result = result.slice(0, n);
    }
    return result;
  }

  findOne(id: string): Gadget {
    const item = this.items.find((g) => g.id === id);
    if (!item) {
      throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    }
    return item;
  }

  create(dto: CreateGadgetDto): Gadget {
    const missing = (['title', 'price', 'warrantyMonths', 'cpu', 'ramGb'] as const).filter(
      (k) => dto?.[k] === undefined || dto[k] === null,
    );
    if (missing.length > 0) {
      throw new BadRequestException(`Відсутні обов’язкові поля: ${missing.join(', ')}`);
    }
    const item: Gadget = { id: randomUUID(), ...dto };
    this.items.push(item);
    return item;
  }

  update(id: string, dto: UpdateGadgetDto): Gadget {
    const item = this.findOne(id);
    // оновлюємо лише передані (визначені) поля
    const changes = Object.fromEntries(Object.entries(dto).filter(([, v]) => v !== undefined));
    Object.assign(item, changes);
    return item;
  }

  remove(id: string): void {
    const index = this.items.findIndex((g) => g.id === id);
    if (index === -1) {
      throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    }
    this.items.splice(index, 1);
  }
}
