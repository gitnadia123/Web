import type { BaseEntity, EntityStatus } from "./base.js";
import { FrozenEntity } from "../decorators/index.js";

/** Сутність варіанта 1 — «Електроніка та гаджети». */
export interface GadgetData extends BaseEntity {
  title: string;
  price: number;
  warrantyMonths: number;
  specs: [cpu: string, ramGb: number];
  status: EntityStatus;
}

// Клас із декоратором @FrozenEntity(): заморожені конструктор та прототип
@FrozenEntity()
export class GadgetEntity implements GadgetData {
  constructor(
    public id: string,
    public title: string,
    public price: number,
    public warrantyMonths: number,
    public specs: [cpu: string, ramGb: number],
    public status: EntityStatus,
    public createdAt: Date,
    public updatedAt: Date,
  ) {}
}
