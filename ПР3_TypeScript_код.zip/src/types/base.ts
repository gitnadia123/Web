// ===== Рівень 1: базові generic-типи =====
export interface BaseEntity {
  id: string;
  createdAt: Date;
  updatedAt: Date;
}

/** Універсальна стандартизована відповідь API. */
export interface ApiResponse<TData> {
  success: boolean;
  data: TData;
  timestamp: Date;
  meta?: Record<string, unknown>;
}

/** Контракт репозиторію. */
export interface IRepository<T extends BaseEntity> {
  create(item: T): T;
  findById(id: string): T | null;
  findAll(): T[];
  deleteById(id: string): boolean;
  update(id: string, patch: UpdateDto<T>): T | null; // Рівень 2
}

// ===== Рівень 2: enum та Utility Types =====
export enum EntityStatus {
  Active = "ACTIVE",
  Archived = "ARCHIVED",
  Draft = "DRAFT",
}

/** Поля, які генеруються системою. */
export type SystemFields = "id" | "createdAt" | "updatedAt";

/** DTO створення: сутність без системних полів. */
export type CreateDto<T extends BaseEntity> = Omit<T, SystemFields>;

/** DTO оновлення: будь-яка підмножина змінюваних полів. */
export type UpdateDto<T extends BaseEntity> = Partial<CreateDto<T>>;

/** Легковажний витяг сутності. */
export type EntitySummary<T extends BaseEntity & { title: string; price: number }> = Pick<T, "id" | "title" | "price">;

/** Лічильники за статусами. */
export type EntityAnalytics = Record<EntityStatus, number>;
