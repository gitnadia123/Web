/** Фабрика декоратора методу: заміряє час виконання через PropertyDescriptor. */
export function LogExecutionTime() {
  return function (_target: object, propertyKey: string, descriptor: PropertyDescriptor): PropertyDescriptor {
    const originalMethod = descriptor.value as (...args: unknown[]) => unknown; // 1. зберігаємо оригінал

    descriptor.value = function (this: unknown, ...args: unknown[]): unknown {
      const start = performance.now(); // 2. час старту
      const result = originalMethod.apply(this, args); // 3. виклик оригіналу зі збереженням this
      const duration = (performance.now() - start).toFixed(2);
      console.log(`[BENCHMARK] Метод ${propertyKey} виконано за ${duration} ms.`);
      return result; // 4. прозоре повернення результату
    };
    return descriptor;
  };
}
