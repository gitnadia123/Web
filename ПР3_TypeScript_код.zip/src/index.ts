import { GadgetService } from "./repositories/index.js";
import { EntityStatus, GadgetEntity } from "./types/index.js";
import type { ApiResponse, CreateDto, UpdateDto } from "./types/index.js";

console.log("=== ІНІЦІАЛІЗАЦІЯ GENERIC SERVICE LAYER ===");
const service = new GadgetService();

const dtos: CreateDto<GadgetEntity>[] = [
  { title: "Ноутбук Pro 16", price: 45000, warrantyMonths: 24, specs: ["M3 Max", 36], status: EntityStatus.Active },
  { title: "Смартфон Nova X", price: 22000, warrantyMonths: 18, specs: ["Snapdragon 8", 12], status: EntityStatus.Active },
  { title: "Планшет Slate 10", price: 12500, warrantyMonths: 12, specs: ["A15", 4], status: EntityStatus.Archived },
];
const created = dtos.map((dto) => {
  const g = service.createFromDto(dto);
  console.log(`- Створено сутність ID: ${g.id} | Статус: ${g.status} | Назва: ${g.title}`);
  return g;
});

const first = created[0]!;
const patch: UpdateDto<GadgetEntity> = { price: 42999 };
await new Promise((r) => setTimeout(r, 20));
const updated = service.update(first.id, patch);
console.log(`- Оновлено сутність ID: ${first.id} | Актуалізовано ціну та updatedAt.`);
console.log(`  (createdAt=${updated?.createdAt.toISOString()}, updatedAt=${updated?.updatedAt.toISOString()})`);
console.log(`- update для неіснуючого id: ${service.update("no-such-id", { price: 1 })}`);

console.log(`Отримано сутностей у репозиторії: ${service.findAll().length}`);
console.log("Легковажні витяги (EntitySummary):", JSON.stringify(service.summaries()));
console.log(`deleteById(неіснуючий): ${service.deleteById("xxx")}; findById(неіснуючий): ${service.findById("xxx")}`);

console.log("\n=== СТАТИСТИКА СТАТУСІВ (RECORD) ===");
console.log(JSON.stringify(service.analytics(), null, 2));

console.log("\n=== СТАНДАРТИЗОВАНА ВІДПОВІДЬ API (GENERIC API RESPONSE) ===");
const response: ApiResponse<GadgetEntity | null> = {
  success: updated !== null,
  data: updated,
  timestamp: new Date(),
  meta: { totalCount: service.summaries().length, version: "1.0.0" },
};
console.log(JSON.stringify(response, null, 2));

console.log("\n=== ЗАХИСТ @FrozenEntity (runtime tamper protection) ===");
console.log(`Object.isFrozen(GadgetEntity) = ${Object.isFrozen(GadgetEntity)}, prototype = ${Object.isFrozen(GadgetEntity.prototype)}`);
try {
  (GadgetEntity.prototype as unknown as Record<string, unknown>)["hack"] = () => "pwned";
  console.log("Прототип змінено (!)");
} catch (e) {
  console.log(`Спроба розширити прототип: ${(e as Error).constructor.name}: ${(e as Error).message}`);
}
console.log(`Екземпляр класу GadgetEntity: ${first instanceof GadgetEntity} (${first.title}, CPU ${first.specs[0]})`);
