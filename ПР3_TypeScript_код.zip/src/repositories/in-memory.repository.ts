import type { BaseEntity, IRepository, UpdateDto } from "../types/index.js";

/** Універсальний in-memory репозиторій для будь-якої сутності з BaseEntity. */
export class InMemoryRepository<T extends BaseEntity> implements IRepository<T> {
  protected items = new Map<string, T>();

  create(item: T): T {
    if (this.items.has(item.id)) throw new Error(`Сутність з id ${item.id} вже існує`);
    this.items.set(item.id, item);
    return item;
  }

  findById(id: string): T | null {
    return this.items.get(id) ?? null;
  }

  findAll(): T[] {
    return [...this.items.values()];
  }

  deleteById(id: string): boolean {
    return this.items.delete(id);
  }

  update(id: string, patch: UpdateDto<T>): T | null {
    const current = this.items.get(id);
    if (!current) return null;
    // id незмінний, updatedAt актуалізується; undefined-поля патчу ігноруються
    const defined = Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined));
    Object.assign(current, defined, { id: current.id, updatedAt: new Date() });
    return current;
  }
}
