import { randomUUID } from "node:crypto";
import { LogExecutionTime } from "../decorators/index.js";
import { EntityStatus, GadgetEntity } from "../types/index.js";
import type { CreateDto, EntityAnalytics, EntitySummary, UpdateDto } from "../types/index.js";
import { InMemoryRepository } from "./in-memory.repository.js";

/** Предметний сервіс: методи create, update, findAll заміряються декоратором. */
export class GadgetService extends InMemoryRepository<GadgetEntity> {
  /** Фабрика: будує сутність із DTO (id, createdAt, updatedAt генеруються тут) і зберігає її через create(). */
  createFromDto(dto: CreateDto<GadgetEntity>): GadgetEntity {
    if (dto.price < 0) throw new Error("Ціна не може бути від’ємною");
    const now = new Date();
    const g = new GadgetEntity(randomUUID().slice(0, 8), dto.title, dto.price, dto.warrantyMonths, dto.specs, dto.status, now, now);
    return this.create(g);
  }

  @LogExecutionTime()
  override create(item: GadgetEntity): GadgetEntity {
    return super.create(item);
  }

  @LogExecutionTime()
  override update(id: string, patch: UpdateDto<GadgetEntity>): GadgetEntity | null {
    return super.update(id, patch);
  }

  @LogExecutionTime()
  override findAll(): GadgetEntity[] {
    return super.findAll();
  }

  summaries(): EntitySummary<GadgetEntity>[] {
    return this.findAll().map(({ id, title, price }) => ({ id, title, price }));
  }

  /** Підрахунок статистики за Record<EntityStatus, number>. */
  analytics(): EntityAnalytics {
    const counters: EntityAnalytics = { [EntityStatus.Active]: 0, [EntityStatus.Archived]: 0, [EntityStatus.Draft]: 0 };
    for (const g of super.findAll()) counters[g.status]++;
    return counters;
  }
}
