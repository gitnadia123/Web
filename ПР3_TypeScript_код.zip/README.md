# Generic In-Memory Repository & Service Layer (ПР3, варіант 1: GadgetEntity)
```bash
npm install
npm start          # tsx src/index.ts
npm run typecheck  # tsc --noEmit
```
