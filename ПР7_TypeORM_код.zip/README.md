# ПР7 — TypeORM + PostgreSQL (NestJS, варіант 1: Електроніка та гаджети)
1. `docker compose up -d` (PostgreSQL 16, nest_user/nest_password, store_db)
2. `npm i --legacy-peer-deps && npm run build && npm run start:prod`
3. Тести — requests.http
