import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ILike, Repository } from 'typeorm';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { PaginationQueryDto } from './dto/pagination-query.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import { GadgetEntity } from './entities/gadget.entity.js';

@Injectable()
export class GadgetsService {
  constructor(
    @InjectRepository(GadgetEntity)
    private readonly gadgetRepo: Repository<GadgetEntity>,
  ) {}

  async create(dto: CreateGadgetDto): Promise<GadgetEntity> {
    const gadget = this.gadgetRepo.create(dto); // створення в пам’яті
    return await this.gadgetRepo.save(gadget); // INSERT
  }

  async findAll(query: PaginationQueryDto) {
    const { page, limit, search, sortBy, order } = query;
    const [data, total] = await this.gadgetRepo.findAndCount({
      where: search ? { title: ILike(`%${search}%`) } : {},
      order: { [sortBy]: order },
      skip: (page - 1) * limit,
      take: limit,
    });
    return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  async findOne(id: string): Promise<GadgetEntity> {
    const gadget = await this.gadgetRepo.findOneBy({ id });
    if (!gadget) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    return gadget;
  }

  async update(id: string, dto: UpdateGadgetDto): Promise<GadgetEntity> {
    const gadget = await this.findOne(id);
    Object.assign(gadget, Object.fromEntries(Object.entries(dto).filter(([, v]) => v !== undefined)));
    return await this.gadgetRepo.save(gadget);
  }

  /** М’яке видалення: записує deletedAt, рядок лишається в таблиці. */
  async remove(id: string): Promise<void> {
    await this.findOne(id);
    await this.gadgetRepo.softDelete(id);
  }

  async restore(id: string): Promise<GadgetEntity> {
    const res = await this.gadgetRepo.restore(id);
    if (!res.affected) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    return this.findOne(id);
  }
}
