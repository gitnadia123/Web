import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GadgetsController } from './gadgets.controller.js';
import { GadgetsService } from './gadgets.service.js';
import { GadgetEntity } from './entities/gadget.entity.js';

@Module({
  imports: [TypeOrmModule.forFeature([GadgetEntity])],
  controllers: [GadgetsController],
  providers: [GadgetsService],
  exports: [GadgetsService],
})
export class GadgetsModule {}
