import { Type } from 'class-transformer';
import { IsIn, IsInt, IsOptional, IsString, Min } from 'class-validator';

export class PaginationQueryDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(1)
  readonly page: number = 1;

  @IsOptional() @Type(() => Number) @IsInt() @Min(1)
  readonly limit: number = 10;

  @IsOptional() @IsString()
  readonly search?: string;

  @IsOptional() @IsIn(['createdAt', 'price', 'title'])
  readonly sortBy: 'createdAt' | 'price' | 'title' = 'createdAt';

  @IsOptional() @IsIn(['ASC', 'DESC'])
  readonly order: 'ASC' | 'DESC' = 'DESC';
}
