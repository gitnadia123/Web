import type { CartItem, DeliveryMethod, Order, OrderStatus } from "./types.js";
import { calculateLineTotal } from "./catalog.js";

let seq = 98214;

export function cartTotal(items: CartItem[]): number {
  return items.reduce((sum, i) => sum + calculateLineTotal(i.product.price, i.quantity), 0);
}

export function createOrder(customerEmail: string, items: CartItem[], delivery: DeliveryMethod): Order {
  if (items.length === 0) throw new Error("Кошик порожній");
  const now = new Date();
  return {
    orderId: `ord-${seq++}-abc`,
    customerEmail,
    items,
    status: "pending",
    delivery,
    createdAt: now,
    updatedAt: now,
  };
}

const FINAL: readonly OrderStatus[] = ["cancelled", "delivered"];

/** Чиста функція: повертає НОВЕ замовлення, оригінал не змінюється. */
export function updateOrderStatus(order: Order, newStatus: OrderStatus): Order {
  if (FINAL.includes(order.status)) {
    throw new Error(`Неможливо змінити статус із фінального «${order.status}» на «${newStatus}»`);
  }
  return { ...order, status: newStatus, updatedAt: new Date() };
}
