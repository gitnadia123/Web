import { calculateLineTotal, createProduct } from "./catalog.js";
import { cartTotal, createOrder, updateOrderStatus } from "./orders.js";
import { isCreditCardPayment, maskCardNumber, processPayment } from "./payments.js";
import { validateCustomerInput } from "./validation.js";
import type { CartItem, PaymentDetails } from "./types.js";

console.log("=== СИСТЕМА ОБРОБКИ ЗАМОВЛЕНЬ (E-COMMERCE CORE) ===\n");

// --- Каталог ---
console.log("[Каталог товарів]");
const laptop = createProduct({
  title: "Ноутбук Pro 16", price: 45000, tags: ["laptop", "pro"], inStock: true,
  description: "16-дюймовий ноутбук", warrantyMonths: 24, powerWatts: 140, specs: ["M3 Max", 36],
});
const mouse = createProduct({
  title: "Бездротова миша", price: 1200, tags: ["accessory"], inStock: true,
  warrantyMonths: 12, specs: ["—", 1],
});
for (const p of [laptop, mouse]) {
  console.log(`- Створено товар #${p.id}: [${p.title}] - ${p.price} грн (В наявності: ${p.inStock ? "так" : "ні"})`);
  if (p === laptop) {
    const [cpu, ramGb] = p.specs; // деструктуризація кортежу
    console.log(`  Специфікації: CPU: ${cpu}, RAM: ${ramGb}GB, Гарантія: ${p.warrantyMonths} міс.`);
  }
}

// --- Кошик ---
console.log("\n[Формування кошика]");
const cart: CartItem[] = [
  { product: laptop, quantity: 1 },
  { product: mouse, quantity: 2 },
];
cart.forEach((item, i) =>
  console.log(`${i + 1}. ${item.product.title} x ${item.quantity} = ${calculateLineTotal(item.product.price, item.quantity)} грн`));
const total = cartTotal(cart);
console.log(`Загальна вартість замовлення: ${total} грн`);
console.log(`Зі знижкою 10% на мишу: ${calculateLineTotal(mouse.price, 2, 10)} грн`);

// --- Замовлення ---
console.log("\n[Створення замовлення]");
const email = validateCustomerInput("  customer@example.com ");
const order = createOrder(email, cart, "courier");
console.log(`Замовлення ID: ${order.orderId}`);
console.log(`Клієнт: ${order.customerEmail}`);
console.log(`Доставка: ${order.delivery}`);
console.log(`Початковий статус: ${order.status}`);
console.log(`Час створення: ${order.createdAt.toISOString()}`);

// --- Життєвий цикл ---
console.log("\n[Зміна життєвого циклу]");
const pause = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));
await pause(50);
const o2 = updateOrderStatus(order, "processing");
console.log(`Оновлення статусу: ${order.status} -> ${o2.status} (Оновлено: ${o2.updatedAt.toISOString()})`);
await pause(50);
const o3 = updateOrderStatus(o2, "shipped");
console.log(`Оновлення статусу: ${o2.status} -> ${o3.status} (Оновлено: ${o3.updatedAt.toISOString()})`);
console.log(`Незмінність оригіналу: order.status = ${order.status}`);

// --- Оплата ---
console.log("\n[Процесинг платежу]");
const payments: PaymentDetails[] = [
  { type: "card", cardNumber: "4111 1111 1111 8821", cardHolder: "John Doe", cvv: "123" },
  { type: "cash", cashAmountToPay: 50000 },
  { type: "online_service", serviceName: "ApplePay", transactionRef: "TX-77AB91" },
];
for (const pay of payments) {
  console.log(`Метод оплати: ${pay.type}`);
  console.log(`Маскування: ${maskCardNumber(pay)}`);
  console.log(`Результат: ${processPayment(pay, total)}`);
  if (isCreditCardPayment(pay)) console.log(`(type guard: картка, власник ${pay.cardHolder})`);
  console.log();
}

// --- Перевірка помилок ---
console.log("[Перевірка обробки помилок]");
const attempt = (name: string, fn: () => unknown): void => {
  try { fn(); console.log(`- ${name}: помилки немає (!)`); }
  catch (e) { console.log(`- ${name}: ${e instanceof Error ? `${e.constructor.name}: ${e.message}` : String(e)}`); }
};
attempt("від’ємна кількість", () => calculateLineTotal(100, -1));
attempt("від’ємна ціна", () => createProduct({ title: "X", price: -5, tags: [], inStock: true, warrantyMonths: 1, specs: ["a", 1] }));
attempt("зміна статусу після shipped→delivered→processing", () =>
  updateOrderStatus(updateOrderStatus(o3, "delivered"), "processing"));
attempt("validateCustomerInput(42)", () => validateCustomerInput(42));
attempt("validateCustomerInput(null)", () => validateCustomerInput(null));
attempt("validateCustomerInput('user.example.com')", () => validateCustomerInput("user.example.com"));
attempt("validateCustomerInput('   ')", () => validateCustomerInput("   "));
