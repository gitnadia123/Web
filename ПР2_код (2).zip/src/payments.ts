import type { CreditCardPayment, PaymentDetails } from "./types.js";

/** Користувацький захисник типу (type predicate). */
export function isCreditCardPayment(payment: PaymentDetails): payment is CreditCardPayment {
  return payment.type === "card";
}

export function maskCardNumber(payment: PaymentDetails): string {
  if (isCreditCardPayment(payment)) {
    // тут payment звужено до CreditCardPayment
    const digits = payment.cardNumber.replace(/\s+/g, "");
    return `**** **** **** ${digits.slice(-4)}`;
  }
  return "Не вимагає маскування";
}

export function processPayment(payment: PaymentDetails, amount: number): string {
  switch (payment.type) {
    case "card":
      return `Успішно списано ${amount} грн з картки платника ${payment.cardHolder}.`;
    case "cash":
      return payment.cashAmountToPay > amount
        ? `Підготуйте решту: ${payment.cashAmountToPay - amount} грн із ${payment.cashAmountToPay} грн (сума замовлення ${amount} грн).`
        : `Готівка при отриманні: ${amount} грн (точна сума).`;
    case "online_service":
      return `Платіж ${payment.transactionRef} авторизовано через ${payment.serviceName}: ${amount} грн.`;
    default: {
      // Якщо додати новий варіант у PaymentDetails без обробки — тут буде помилка компіляції
      const _exhaustiveCheck: never = payment;
      throw new Error(`Непідтримуваний спосіб оплати: ${JSON.stringify(_exhaustiveCheck)}`);
    }
  }
}
