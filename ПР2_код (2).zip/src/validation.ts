/** Безпечна обробка невідомих даних: unknown + звуження через typeof. */
export function validateCustomerInput(input: unknown): string {
  if (typeof input !== "string") {
    throw new TypeError(`Очікувався рядок, отримано: ${input === null ? "null" : typeof input}`);
  }
  const email = input.trim();
  if (email === "") throw new Error("Рядок не може бути порожнім");
  if (!email.includes("@")) throw new Error(`Некоректний формат email (немає символу @): ${email}`);
  return email;
}
