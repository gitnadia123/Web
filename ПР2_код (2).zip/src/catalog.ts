import type { Product, ProductInput } from "./types.js";

let nextId = 1;

/** Створює товар: перевіряє дані та присвоює числовий id. */
export function createProduct(productData: ProductInput): Product {
  if (productData.title.trim() === "") throw new Error("Назва товару не може бути порожньою");
  if (productData.price < 0) throw new Error(`Ціна не може бути від’ємною: ${productData.price}`);
  if (productData.specs[1] <= 0) throw new Error("Обсяг RAM має бути додатним");
  return { id: nextId++, ...productData };
}

/** Вартість позиції з урахуванням знижки (у відсотках). */
export function calculateLineTotal(price: number, quantity: number, discountPercent: number = 0): number {
  if (price < 0) throw new Error(`Ціна не може бути від’ємною: ${price}`);
  if (quantity < 0) throw new Error(`Кількість не може бути від’ємною: ${quantity}`);
  if (discountPercent < 0 || discountPercent > 100) throw new Error("Знижка має бути в межах 0–100%");
  const total = price * quantity * (1 - discountPercent / 100);
  return Math.round(total * 100) / 100;
}
