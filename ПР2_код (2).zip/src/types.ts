// ===== Рівень 1: базові типи =====
export type EntityId = string | number;

export interface BaseProduct {
  readonly id: EntityId;
  title: string;
  price: number;
  description?: string;
  tags: string[];
  inStock: boolean;
}

/** Специфікація «Електроніка та гаджети» (варіант 1). */
export interface ElectronicsSpecifics {
  warrantyMonths: number;
  powerWatts?: number;
  specs: [cpu: string, ramGb: number]; // кортеж із мітками
}

export type Product = BaseProduct & ElectronicsSpecifics;

/** Дані для створення товару: id генерується системою. */
export type ProductInput = Omit<Product, "id">;

// ===== Рівень 2: життєвий цикл замовлення =====
export type OrderStatus = "pending" | "processing" | "shipped" | "delivered" | "cancelled";
export type DeliveryMethod = "courier" | "post_locker" | "store_pickup";

export interface CartItem {
  product: Product;
  quantity: number;
}

export type TimestampMetadata = { readonly createdAt: Date; updatedAt: Date };

export type Order = {
  readonly orderId: string;
  customerEmail: string;
  items: CartItem[];
  status: OrderStatus;
  delivery: DeliveryMethod;
} & TimestampMetadata;

// ===== Рівень 3: способи оплати (discriminated union) =====
export type CreditCardPayment = { type: "card"; cardNumber: string; cardHolder: string; cvv: string };
export type CashOnDeliveryPayment = { type: "cash"; cashAmountToPay: number };
export type OnlineServicePayment = {
  type: "online_service";
  serviceName: "ApplePay" | "GooglePay";
  transactionRef: string;
};
export type PaymentDetails = CreditCardPayment | CashOnDeliveryPayment | OnlineServicePayment;
