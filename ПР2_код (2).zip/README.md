# E-Commerce Core Engine (TypeScript, strict) — ПР2, варіант 1 (Електроніка та гаджети)

```bash
npm install
npm start          # tsx src/index.ts
npm run typecheck  # tsc --noEmit
npm run build      # tsc -> dist/
```
