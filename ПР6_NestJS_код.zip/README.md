# ПР6 — Валідація та обробка запитів (NestJS, варіант 1: Електроніка та гаджети)
npm i --legacy-peer-deps && npm run build && npm run start:prod
Pipeline: Middleware → Guards → Interceptor(before) → Pipes (TrimPipe, ValidationPipe) → Handler → Interceptor(after) → Filter.
