import { Injectable, Logger, Scope } from '@nestjs/common';

/** Провайдер зі Scope.REQUEST: новий екземпляр створюється для кожного HTTP-запиту. */
@Injectable({ scope: Scope.REQUEST })
export class RequestIdService {
  private static created = 0;
  private readonly logger = new Logger(RequestIdService.name);
  readonly requestId: string;
  readonly instanceNumber: number;

  constructor() {
    this.instanceNumber = ++RequestIdService.created;
    this.requestId = `req-${String(this.instanceNumber).padStart(4, '0')}`;
    this.logger.log(`Створено новий екземпляр #${this.instanceNumber} (${this.requestId})`);
  }

  static get totalCreated(): number {
    return RequestIdService.created;
  }
}
