import { Module } from '@nestjs/common';
import { SharedModule } from '../shared/shared.module.js';
import { GadgetsController } from './gadgets.controller.js';
import { GadgetsService } from './gadgets.service.js';

@Module({
  imports: [SharedModule],
  controllers: [GadgetsController],
  providers: [GadgetsService],
  exports: [GadgetsService], // доступний модулям, що імпортують GadgetsModule
})
export class GadgetsModule {}
