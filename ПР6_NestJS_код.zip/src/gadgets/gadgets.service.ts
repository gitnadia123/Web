import { BadRequestException, Injectable, Logger, NotFoundException, OnModuleInit } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { SlugService } from '../shared/slug/slug.service.js';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import type { GadgetEntity } from './entities/gadget.entity.js';

@Injectable()
export class GadgetsService implements OnModuleInit {
  private readonly logger = new Logger(GadgetsService.name);
  private items: GadgetEntity[] = [];

  // Constructor injection сервісу з SharedModule
  constructor(private readonly slugService: SlugService) {}

  onModuleInit(): void {
    this.items.push(
      { id: 'gadget-1', title: 'Ноутбук Pro 16', slug: this.slugService.generateSlug('Ноутбук Pro 16'), price: 45000, warrantyMonths: 24, cpu: 'M3 Max', ramGb: 36 },
      { id: 'gadget-2', title: 'Wireless Mouse', slug: this.slugService.generateSlug('Wireless Mouse'), price: 1200, warrantyMonths: 12, cpu: 'n/a', ramGb: 0 },
    );
    this.logger.log('Ініціалізація модуля завершена. Завантажено початкові тестові дані.');
  }

  findAll(): GadgetEntity[] {
    return this.items;
  }

  findOne(id: string): GadgetEntity {
    const item = this.items.find((g) => g.id === id);
    if (!item) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    return item;
  }

  create(dto: CreateGadgetDto): GadgetEntity {
    const missing = (['title', 'price', 'warrantyMonths', 'cpu', 'ramGb'] as const).filter(
      (k) => dto?.[k] === undefined || dto[k] === null,
    );
    if (missing.length > 0) throw new BadRequestException(`Відсутні обов’язкові поля: ${missing.join(', ')}`);
    const item: GadgetEntity = { id: randomUUID(), slug: this.slugService.generateSlug(dto.title), ...dto };
    this.items.push(item);
    return item;
  }

  update(id: string, dto: UpdateGadgetDto): GadgetEntity {
    const item = this.findOne(id);
    const changes = Object.fromEntries(Object.entries(dto).filter(([, v]) => v !== undefined));
    Object.assign(item, changes);
    if (dto.title !== undefined) item.slug = this.slugService.generateSlug(dto.title);
    return item;
  }

  remove(id: string): void {
    const index = this.items.findIndex((g) => g.id === id);
    if (index === -1) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    this.items.splice(index, 1);
  }
}
