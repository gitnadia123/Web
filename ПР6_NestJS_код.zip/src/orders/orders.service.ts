import { BadRequestException, Inject, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { GadgetsService } from '../gadgets/gadgets.service.js';
import { FEE_CALCULATOR } from '../shared/config/fee-calculator.provider.js';
import type { FeeCalculator } from '../shared/config/fee-calculator.provider.js';
import { STORE_CONFIG } from '../shared/config/app-config.provider.js';
import type { StoreConfig } from '../shared/config/app-config.provider.js';
import { CreateOrderDto } from './dto/create-order.dto.js';

export interface Order {
  orderId: string;
  customerEmail: string;
  productTitle: string;
  productSlug: string;
  unitPrice: number;
  quantity: number;
  subtotal: number;
  taxAmount: number;
  total: number;
  currency: string;
  status: 'confirmed';
  createdAt: string;
}

@Injectable()
export class OrdersService implements OnModuleInit {
  private readonly logger = new Logger(OrdersService.name);
  private orders: Order[] = [];

  constructor(
    private readonly gadgetsService: GadgetsService, // сервіс із GadgetsModule (exports)
    @Inject(FEE_CALCULATOR) private readonly fees: FeeCalculator, // useFactory-провайдер
    @Inject(STORE_CONFIG) private readonly config: StoreConfig, // useValue-провайдер
  ) {}

  onModuleInit(): void {
    this.logger.log('Сервіс замовлень успішно підключено до білінгу та каталогу.');
  }

  createOrder(dto: CreateOrderDto): Order {
    if (!Number.isInteger(dto?.quantity) || dto.quantity < 1) {
      throw new BadRequestException('quantity має бути цілим числом ≥ 1');
    }
    const product = this.gadgetsService.findOne(dto.productId); // NotFoundException, якщо товару немає
    const subtotal = product.price * dto.quantity;
    const taxAmount = this.fees.calculateTax(subtotal);
    const order: Order = {
      orderId: `ord-${Date.now()}-${this.orders.length + 1}`,
      customerEmail: dto.customerEmail,
      productTitle: product.title,
      productSlug: product.slug,
      unitPrice: product.price,
      quantity: dto.quantity,
      subtotal,
      taxAmount,
      total: subtotal + taxAmount,
      currency: this.config.defaultCurrency,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };
    this.orders.push(order);
    return order;
  }

  findAll(): Order[] {
    return this.orders;
  }
}
