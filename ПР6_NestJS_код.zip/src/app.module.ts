import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { HttpLoggingMiddleware } from './common/middleware/http-logger.middleware.js';
import { GadgetsModule } from './gadgets/gadgets.module.js';
import { OrdersModule } from './orders/orders.module.js';
import { SharedModule } from './shared/shared.module.js';

@Module({
  imports: [GadgetsModule, OrdersModule, SharedModule],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(HttpLoggingMiddleware).forRoutes('*');
  }
}
