# ПР8 — Зв’язки між сутностями та міграції (NestJS + TypeORM, варіант 1)
Сутності: GadgetEntity, BrandEntity (1:M), FeatureEntity (M:N), WarrantyEntity (1:1).

    docker compose up -d
    npm i --legacy-peer-deps
    npm run migration:run      # збирає проєкт і застосовує міграції
    npm run start:prod

Міграції: `npm run migration:generate -- src/database/migrations/<Name>`, `migration:run`, `migration:revert`, `migration:show`.
Тести: requests.http
