#!/usr/bin/env bash
# Власний CA + серверний сертифікат (SAN: localhost, 127.0.0.1) для локального HTTPS-стенда
set -e
cd "$(dirname "$0")"
openssl genrsa -out ca.key 2048 2>/dev/null
openssl req -x509 -new -nodes -key ca.key -sha256 -days 365 -subj "/C=UA/O=Lab Stand/CN=Lab Stand Root CA" -out ca.pem
openssl genrsa -out server.key 2048 2>/dev/null
openssl req -new -key server.key -subj "/C=UA/O=Lab Stand/CN=localhost" -out server.csr
printf "subjectAltName=DNS:localhost,IP:127.0.0.1\nbasicConstraints=CA:FALSE\nkeyUsage=digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n" > ext.cnf
openssl x509 -req -in server.csr -CA ca.pem -CAkey ca.key -CAcreateserial -out server.pem -days 90 -sha256 -extfile ext.cnf 2>/dev/null
rm -f server.csr ext.cnf ca.srl
echo "OK: ca.pem, server.pem, server.key"
