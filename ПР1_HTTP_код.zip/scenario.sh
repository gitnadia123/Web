#!/usr/bin/env bash
# Сценарій ПР1 на локальному стенді (node stand.mjs). Для реальних сайтів замініть $B на https://dummyjson.com / https://httpbin.org
unset HTTP_PROXY HTTPS_PROXY http_proxy https_proxy ALL_PROXY NO_PROXY no_proxy
cd "$(dirname "$0")"; mkdir -p out; rm -f out/c_*.txt cookies.txt
B=https://localhost:8443; C="--cacert certs/ca.pem"; J='Content-Type: application/json'
run(){ f=out/c_$1.txt; shift; echo "\$ $DISP" > $f; "$@" >> $f 2>&1; echo >> $f; }
DISP="curl --version | head -1"; run 00 bash -c "curl --version | head -1"
# --- Рівень 1 (Postman-запити через curl) ---
DISP="curl -s -i $C $B/products/1 -w '\n[status=%{http_code} time=%{time_total}s size=%{size_download} B]'"; run 11 curl -s -i $C $B/products/1 -w '\n[status=%{http_code} time=%{time_total}s size=%{size_download} B]'
DISP="curl -s -i $C -X POST $B/products/add -H '$J' -d '{\"title\":\"BMW Pencil\",\"price\":12.5}'"; run 12 curl -s -i $C -X POST $B/products/add -H "$J" -d '{"title":"BMW Pencil","price":12.5}'
DISP="curl -s -i $C -X PUT $B/products/1 -H '$J' -d '{\"title\":\"iPhone Galaxy +1\"}'"; run 13 curl -s -i $C -X PUT $B/products/1 -H "$J" -d '{"title":"iPhone Galaxy +1"}'
DISP="curl -s -i $C -X DELETE $B/products/1"; run 14 curl -s -i $C -X DELETE $B/products/1
# --- Рівень 2 ---
DISP="curl -s $C '$B/users?limit=2&select=firstName,email'"; run 21 curl -s $C "$B/users?limit=2&select=firstName,email"
DISP="curl -s -i $C -X POST $B/posts/add -H '$J' -d '{\"title\":\"I am in love with someone.\",\"userId\":5}'"; run 22 curl -s -i $C -X POST $B/posts/add -H "$J" -d '{"title":"I am in love with someone.","userId":5}'
DISP="curl -I $C $B/products"; run 23 curl -s -I $C $B/products
DISP="curl -i $C $B/status/404"; run 24 curl -s -i $C $B/status/404
DISP="curl -i $C $B/status/500"; run 25 curl -s -i $C $B/status/500
DISP="curl -s -X POST $B/auth/login ... (username=emilys)"; run 26 curl -s $C -X POST $B/auth/login -H "$J" -d '{"username":"emilys","password":"emilyspass"}'
TOKEN=$(curl -s $C -X POST $B/auth/login -H "$J" -d '{"username":"emilys","password":"emilyspass"}' | jq -r .accessToken)
DISP="curl -s -i $C $B/auth/me   # без токена"; run 27 curl -s -i $C $B/auth/me
DISP="curl -s -i $C $B/auth/me -H 'Authorization: Bearer \$TOKEN'"; run 28 curl -s -i $C $B/auth/me -H "Authorization: Bearer $TOKEN"
DISP="curl -s $C -o /dev/null -w 'DNS Lookup: %{time_namelookup}s\\nTCP Connect: %{time_connect}s\\nTLS Handshake: %{time_appconnect}s\\nTime To First Byte (TTFB): %{time_starttransfer}s\\nTotal Transaction Time: %{time_total}s\\n' $B/products"
run 29 curl -s $C -o /dev/null -w "DNS Lookup: %{time_namelookup}s\nTCP Connect: %{time_connect}s\nTLS Handshake: %{time_appconnect}s\nTime To First Byte (TTFB): %{time_starttransfer}s\nTotal Transaction Time: %{time_total}s\n" $B/products
# --- Рівень 3 ---
DISP="curl -v $C $B/products/1"; run 31 curl -v -s $C $B/products/1
DISP="curl -I http://localhost:8080/products/1"; run 32 curl -s -I http://localhost:8080/products/1
DISP="curl -s -i -c cookies.txt \"$B/cookies/set?user_role=student&session_key=lab1_token\""; run 33 curl -s -i $C -c cookies.txt "$B/cookies/set?user_role=student&session_key=lab1_token"
DISP="cat cookies.txt"; run 34 cat cookies.txt
DISP="curl -s -i -b cookies.txt $B/cookies"; run 35 curl -s -i $C -b cookies.txt $B/cookies
DISP="curl -i \"$B/response-headers?Set-Cookie=session_id=xyz789;%20Path=/;%20Secure;%20HttpOnly;%20SameSite=Strict\""; run 36 curl -s -i $C "$B/response-headers?Set-Cookie=session_id=xyz789;%20Path=/;%20Secure;%20HttpOnly;%20SameSite=Strict"
DISP="curl -i -X OPTIONS $B/post -H 'Origin: https://my-college-app.edu' -H 'Access-Control-Request-Method: POST' -H 'Access-Control-Request-Headers: Content-Type, Authorization'"
run 37 curl -s -i $C -X OPTIONS $B/post -H "Origin: https://my-college-app.edu" -H "Access-Control-Request-Method: POST" -H "Access-Control-Request-Headers: Content-Type, Authorization"
DISP="openssl s_client -connect localhost:8443 -servername localhost -CAfile certs/ca.pem | openssl x509 -noout -subject -issuer -dates -ext subjectAltName"
run 38 bash -c "echo | openssl s_client -connect localhost:8443 -servername localhost -CAfile certs/ca.pem 2>/dev/null | openssl x509 -noout -subject -issuer -dates -ext subjectAltName"
DISP="curl https://localhost:8443/products/1   # без --cacert (CA стенда не довірений)"; run 39 bash -c "curl -sS https://localhost:8443/products/1 2>&1 | head -5"
