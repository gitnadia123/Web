// Локальний стенд для ПР1: імітує потрібні ендпоінти dummyjson.com та httpbin.org.
// Запуск: node stand.mjs   (HTTPS :8443, HTTP :8080 -> редірект 308 на HTTPS)
import https from 'node:https';
import http from 'node:http';
import fs from 'node:fs';
import crypto from 'node:crypto';

const HTTPS_PORT = 8443, HTTP_PORT = 8080;
const SECRET = 'lab-stand-secret';
const b64 = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
function jwt(payload) {
  const h = b64({ alg: 'HS256', typ: 'JWT' }), p = b64(payload);
  const s = crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${s}`;
}
function verify(t) {
  const [h, p, s] = (t || '').split('.');
  if (!s) return null;
  const ok = crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url') === s;
  return ok ? JSON.parse(Buffer.from(p, 'base64url').toString()) : null;
}

const PRODUCTS = [
  { id: 1, title: 'Essence Mascara Lash Princess', description: 'Popular mascara known for its volumizing and lengthening effects.', category: 'beauty', price: 9.99, discountPercentage: 10.48, rating: 2.56, stock: 99, brand: 'Essence', sku: 'BEA-ESS-ESS-001' },
  { id: 2, title: 'Eyeshadow Palette with Mirror', description: 'Versatile palette with a range of shades.', category: 'beauty', price: 19.99, discountPercentage: 18.19, rating: 2.86, stock: 34, brand: 'Glamour Beauty', sku: 'BEA-GLA-EYE-002' },
  { id: 3, title: 'Powder Canister', description: 'Finishing powder with a lightweight texture.', category: 'beauty', price: 14.99, discountPercentage: 9.84, rating: 4.64, stock: 89, brand: 'Velvet Touch', sku: 'BEA-VEL-POW-003' },
];
const USERS = [
  { id: 1, firstName: 'Emily', email: 'emily.johnson@x.dummyjson.com', username: 'emilys', password: 'emilyspass', lastName: 'Johnson', gender: 'female', image: 'https://dummyjson.com/icon/emilys/128' },
  { id: 2, firstName: 'Michael', email: 'michael.williams@x.dummyjson.com', username: 'michaelw', password: 'michaelwpass', lastName: 'Williams', gender: 'male', image: 'https://dummyjson.com/icon/michaelw/128' },
  { id: 3, firstName: 'Sophia', email: 'sophia.brown@x.dummyjson.com', username: 'sophiab', password: 'sophiabpass', lastName: 'Brown', gender: 'female', image: 'https://dummyjson.com/icon/sophiab/128' },
];
let nextProduct = 195, nextPost = 252;

const readBody = (req) => new Promise((res) => { let d = ''; req.on('data', (c) => (d += c)); req.on('end', () => res(d)); });
const parseJson = (s) => { try { return JSON.parse(s || '{}'); } catch { return null; } };
const parseCookies = (h) => Object.fromEntries((h || '').split(/;\s*/).filter(Boolean).map((c) => c.split('=').map((x) => x.trim())));

async function handler(req, res) {
  const url = new URL(req.url, 'https://localhost');
  const path = url.pathname;
  const send = (code, obj, headers = {}) => {
    const body = JSON.stringify(obj, null, 2);
    const etag = 'W/"' + crypto.createHash('md5').update(body).digest('hex').slice(0, 12) + '"';
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', ETag: etag, Server: 'lab-stand/1.0', 'Cache-Control': 'no-cache', ...headers });
    res.end(req.method === 'HEAD' ? undefined : body);
  };
  const cors = { 'Access-Control-Allow-Origin': req.headers.origin ?? '*' };

  // ---- CORS preflight (httpbin-подібна поведінка) ----
  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      Server: 'lab-stand/1.0',
      'Access-Control-Allow-Origin': req.headers.origin ?? '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': req.headers['access-control-request-headers'] ?? '',
      'Access-Control-Max-Age': '3600',
      'Content-Length': '0',
    });
    return res.end();
  }

  // ---- dummyjson-подібні ресурси ----
  if (path === '/products' && req.method === 'GET') return send(200, { products: PRODUCTS, total: PRODUCTS.length, skip: 0, limit: 30 }, cors);
  let m;
  if ((m = path.match(/^\/products\/(\d+)$/))) {
    const id = Number(m[1]);
    const p = PRODUCTS.find((x) => x.id === id);
    if (!p) return send(404, { message: `Product with id '${id}' not found` });
    if (req.method === 'GET') return send(200, p, cors);
    if (req.method === 'PUT') { const b = parseJson(await readBody(req)) ?? {}; return send(200, { ...p, ...b }, cors); }
    if (req.method === 'DELETE') return send(200, { ...p, isDeleted: true, deletedOn: new Date().toISOString() }, cors);
  }
  if (path === '/products/add' && req.method === 'POST') {
    const b = parseJson(await readBody(req));
    if (!b) return send(400, { message: 'Invalid JSON' });
    return send(201, { id: nextProduct++, ...b }, cors);
  }
  if (path === '/posts/add' && req.method === 'POST') {
    const b = parseJson(await readBody(req));
    if (!b) return send(400, { message: 'Invalid JSON' });
    return send(201, { id: nextPost++, ...b }, cors);
  }
  if (path === '/users' && req.method === 'GET') {
    const limit = Number(url.searchParams.get('limit') ?? 30);
    const select = (url.searchParams.get('select') ?? '').split(',').filter(Boolean);
    let list = USERS.slice(0, limit).map(({ password, ...u }) => u);
    if (select.length) list = list.map((u) => Object.fromEntries([['id', u.id], ...select.map((k) => [k, u[k]])]));
    return send(200, { users: list, total: USERS.length, skip: 0, limit }, cors);
  }
  if (path === '/auth/login' && req.method === 'POST') {
    const b = parseJson(await readBody(req)) ?? {};
    const u = USERS.find((x) => x.username === b.username && x.password === b.password);
    if (!u) return send(400, { message: 'Invalid credentials' });
    const now = Math.floor(Date.now() / 1000);
    const { password, ...pub } = u;
    return send(200, { ...pub, accessToken: jwt({ id: u.id, username: u.username, iat: now, exp: now + 3600 }) }, cors);
  }
  if (path === '/auth/me' && req.method === 'GET') {
    const t = (req.headers.authorization ?? '').replace(/^Bearer /, '');
    const claims = verify(t);
    if (!claims || claims.exp < Date.now() / 1000) return send(401, { message: 'Invalid/Expired Token!' });
    const { password, ...pub } = USERS.find((x) => x.id === claims.id);
    return send(200, pub, cors);
  }

  // ---- httpbin-подібні ресурси ----
  if ((m = path.match(/^\/status\/(\d{3})$/))) {
    const code = Number(m[1]);
    res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8', Server: 'lab-stand/1.0', 'Content-Length': 0 });
    return res.end();
  }
  if (path === '/cookies/set') {
    const cookies = [...url.searchParams.entries()].map(([k, v]) => `${k}=${v}; Path=/`);
    res.writeHead(302, { Location: '/cookies', 'Set-Cookie': cookies, Server: 'lab-stand/1.0', 'Content-Length': 0 });
    return res.end();
  }
  if (path === '/cookies') return send(200, { cookies: parseCookies(req.headers.cookie) });
  if (path === '/response-headers') {
    const h = {}; const body = {};
    for (const [k, v] of url.searchParams) { h[k] = v; body[k] = v; }
    return send(200, body, h);
  }
  if (path === '/post' && req.method === 'POST') return send(200, { data: await readBody(req), headers: req.headers, url: `https://localhost:${HTTPS_PORT}/post` }, cors);

  return send(404, { message: 'Not found' });
}

const opts = { key: fs.readFileSync(new URL('./certs/server.key', import.meta.url)), cert: fs.readFileSync(new URL('./certs/server.pem', import.meta.url)) };
https.createServer(opts, handler).listen(HTTPS_PORT, () => console.log(`[stand] HTTPS https://localhost:${HTTPS_PORT}`));
http.createServer((req, res) => {
  res.writeHead(308, { Location: `https://localhost:${HTTPS_PORT}${req.url}`, Server: 'lab-stand/1.0', 'Content-Length': 0 });
  res.end();
}).listen(HTTP_PORT, () => console.log(`[stand] HTTP  http://localhost:${HTTP_PORT} -> 308 -> HTTPS`));
