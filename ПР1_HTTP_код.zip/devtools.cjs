const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1100, height: 700 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Network.enable');
  const ev = { resp: null, extra: null, fin: null, rid: null };
  cdp.on('Network.requestWillBeSent', e => { if (e.request.url.endsWith('/products')) ev.rid = e.requestId; });
  cdp.on('Network.responseReceived', e => { if (e.requestId === ev.rid) ev.resp = e.response; });
  cdp.on('Network.requestWillBeSentExtraInfo', e => { if (e.requestId === ev.rid) ev.extra = e; });
  cdp.on('Network.loadingFinished', e => { if (e.requestId === ev.rid) ev.fin = e; });
  await page.goto('https://localhost:8443/products', { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);
  const r = ev.resp, t = r.timing, h = r.headers, rh = ev.extra.headers;
  const hh = (o, k) => o[k] ?? o[Object.keys(o).find(x => x.toLowerCase() === k)] ?? '—';
  const f = x => (x < 0 ? '—' : x.toFixed(3) + ' ms');
  const rows = {
    General: [['Request URL', r.url], ['Request Method', 'GET'], ['Status Code', `${r.status} ${r.statusText || 'OK'}`], ['Remote Address', `${r.remoteIPAddress}:${r.remotePort}`], ['Protocol', r.protocol + ' / ' + (r.securityDetails?.protocol ?? '')]],
    'Response Headers': ['content-type', 'date', 'server', 'etag'].map(k => [k, hh(h, k)]),
    'Request Headers': ['accept', 'user-agent', 'accept-encoding'].map(k => [k, hh(rh, k)]),
    Timing: [['DNS Lookup', f(t.dnsEnd - t.dnsStart)], ['Initial connection (TCP)', f(t.connectEnd - t.connectStart)], ['SSL (TLS)', f(t.sslEnd - t.sslStart)], ['Waiting for server response (TTFB)', f(t.receiveHeadersStart - t.sendEnd)], ['Content Download', f((ev.fin.timestamp - t.requestTime) * 1000 - t.receiveHeadersEnd)]],
  };
  fs.writeFileSync('out/devtools.json', JSON.stringify(rows, null, 2));
  let html = `<html><body style="font:14px system-ui;margin:16px;background:#fff"><div style="background:#f1f3f4;padding:6px 10px;border-bottom:1px solid #ccc;font-weight:600">DevTools → Network → products (Headers / Timing)</div>`;
  for (const [sec, items] of Object.entries(rows)) {
    html += `<h3 style="margin:12px 0 4px;background:#e8eaed;padding:3px 8px">${sec}</h3><table style="border-collapse:collapse;width:100%">`;
    for (const [k, v] of items) html += `<tr><td style="width:260px;color:#80868b;vertical-align:top;padding:2px 8px">${k}:</td><td style="padding:2px 8px;font-family:monospace;word-break:break-all">${String(v).replace(/</g, '&lt;')}</td></tr>`;
    html += '</table>';
  }
  const p2 = await ctx.newPage();
  await p2.setContent(html + '</body></html>');
  await p2.screenshot({ path: 'shots/devtools.png', fullPage: true });
  // також сама сторінка у браузері
  await page.screenshot({ path: 'shots/browser_products.png' });
  console.log(JSON.stringify(rows, null, 1));
  await browser.close();
})();
