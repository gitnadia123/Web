// Локальна SMTP-пастка з веб-інтерфейсом (аналог Mailpit): SMTP :1025, Web UI :8025.
// Використовується, коли Docker недоступний. Запуск: node mail-trap/trap.mjs
import { createServer } from 'node:http';
import { SMTPServer } from 'smtp-server';
import { simpleParser } from 'mailparser';

const messages = [];
const smtp = new SMTPServer({
  authOptional: true,
  disabledCommands: ['STARTTLS'],
  onData(stream, session, cb) {
    simpleParser(stream).then((m) => {
      messages.unshift({
        id: String(Date.now()) + messages.length,
        from: m.from?.text, to: m.to?.text, subject: m.subject, date: new Date().toISOString(), html: m.html || m.textAsHtml || '',
      });
      console.log(`[SMTP] ${m.to?.text} ← "${m.subject}"`);
      cb();
    }).catch(cb);
  },
});
smtp.listen(1025, () => console.log('SMTP-пастка слухає :1025'));

const page = (body) => `<!doctype html><meta charset="utf-8"><title>Mail Trap</title>
<style>body{font-family:system-ui,Arial;margin:0;background:#f3f4f6}header{background:#111827;color:#fff;padding:12px 20px;font-weight:bold}
main{padding:16px;max-width:1000px;margin:auto}a{color:#1d4ed8;text-decoration:none}table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden}
td,th{padding:10px 12px;border-bottom:1px solid #e5e7eb;text-align:left;font-size:14px}iframe{width:100%;height:640px;border:1px solid #e5e7eb;background:#fff;border-radius:8px}</style>
<header>📬 Mail Trap (локальна SMTP-пастка) · ${messages.length} лист(ів)</header><main>${body}</main>`;

createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/api/messages') { res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify(messages.map(({ html, ...m }) => m))); }
  const m = /^\/(m|raw)\//.test(url.pathname) && messages.find((x) => x.id === url.pathname.split('/')[2]);
  if (url.pathname.startsWith('/raw/') && m) { res.setHeader('content-type', 'text/html; charset=utf-8'); return res.end(m.html); }
  res.setHeader('content-type', 'text/html; charset=utf-8');
  if (m) return res.end(page(`<p><a href="/">← Усі листи</a></p><p><b>Від:</b> ${m.from}<br><b>Кому:</b> ${m.to}<br><b>Тема:</b> ${m.subject}</p><iframe src="/raw/${m.id}"></iframe>`));
  res.end(page(`<table><tr><th>Кому</th><th>Тема</th><th>Час</th></tr>${messages.map((x) => `<tr><td>${x.to}</td><td><a href="/m/${x.id}">${x.subject}</a></td><td>${new Date(x.date).toLocaleTimeString('uk-UA')}</td></tr>`).join('')}</table>`));
}).listen(8025, () => console.log('Web UI: http://localhost:8025'));
