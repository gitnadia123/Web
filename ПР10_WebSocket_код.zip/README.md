# ПР10 — WebSocket (Socket.IO), SSE та email-нотифікації (NestJS, варіант 1)
Кімната `order_<orderId>`, подія `orderStatusChanged`, лист — підтвердження покупки та зміна статусу гарантії.

    docker compose up -d          # PostgreSQL + Mailpit (SMTP 1025, UI http://localhost:8025)
    npm i --legacy-peer-deps
    npm run migration:run
    npm run start:prod
    # відкрити http://localhost:3000/client.html у двох вкладках

Без Docker: `node mail-trap/trap.mjs` — локальна SMTP-пастка (порти 1025/8025), еквівалент Mailpit.
Тести: requests.http
