import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, ParseUUIDPipe, Post } from '@nestjs/common';
import { BrandsService } from './brands.service.js';
import { CreateBrandDto } from './dto/create-brand.dto.js';

@Controller('brands')
export class BrandsController {
  constructor(private readonly brands: BrandsService) {}

  @Post() @HttpCode(HttpStatus.CREATED)
  create(@Body() dto: CreateBrandDto) { return this.brands.create(dto); }

  @Get()
  findAll() { return this.brands.findAll(); }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) { return this.brands.findOne(id); }

  @Delete(':id') @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string) { return this.brands.remove(id); }
}
