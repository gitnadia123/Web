import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { PaginationQueryDto } from './dto/pagination-query.dto.js';
import { TransactionalGadgetDto } from './dto/transactional-gadget.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import { GadgetsService } from './gadgets.service.js';

@Controller('gadgets')
export class GadgetsController {
  constructor(private readonly gadgetsService: GadgetsService) {}

  @Get()
  findAll(@Query() query: PaginationQueryDto) {
    return this.gadgetsService.findAll(query);
  }

  @Get(':id/full')
  findFull(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.findFull(id);
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.findOne(id);
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  create(@Body() dto: CreateGadgetDto) {
    return this.gadgetsService.create(dto);
  }

  @Post('transactional')
  @HttpCode(HttpStatus.CREATED)
  createTransactional(@Body() dto: TransactionalGadgetDto) {
    return this.gadgetsService.createTransactional(dto);
  }

  @Patch(':id/restore')
  restore(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.restore(id);
  }

  @Patch(':id')
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateGadgetDto) {
    return this.gadgetsService.update(id, dto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.remove(id);
  }
}
