import { BadRequestException, Inject, NotFoundException, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { GadgetsService } from '../gadgets/gadgets.service.js';
import { FEE_CALCULATOR } from '../shared/config/fee-calculator.provider.js';
import type { FeeCalculator } from '../shared/config/fee-calculator.provider.js';
import { SlugService } from '../shared/slug/slug.service.js';
import { STORE_CONFIG } from '../shared/config/app-config.provider.js';
import type { StoreConfig } from '../shared/config/app-config.provider.js';
import { EventsGateway } from '../notifications/events.gateway.js';
import { MailService } from '../notifications/mail/mail.service.js';
import { orderEmailHtml, statusText } from '../notifications/mail/order-email.template.js';
import { OrderStatus, UpdateOrderStatusDto } from './dto/update-order-status.dto.js';
import { CreateOrderDto } from './dto/create-order.dto.js';

export interface Order {
  orderId: string;
  customerEmail: string;
  productTitle: string;
  productSlug: string;
  unitPrice: number;
  quantity: number;
  subtotal: number;
  taxAmount: number;
  total: number;
  currency: string;
  status: OrderStatus;
  createdAt: string;
}

@Injectable()
export class OrdersService implements OnModuleInit {
  private readonly logger = new Logger(OrdersService.name);
  private orders: Order[] = [];

  constructor(
    private readonly gadgetsService: GadgetsService,
    private readonly slugService: SlugService, // сервіс із GadgetsModule (exports)
    @Inject(FEE_CALCULATOR) private readonly fees: FeeCalculator, // useFactory-провайдер
    @Inject(STORE_CONFIG) private readonly config: StoreConfig, // useValue-провайдер
    private readonly events: EventsGateway,
    private readonly mail: MailService,
  ) {}

  onModuleInit(): void {
    this.logger.log('Сервіс замовлень успішно підключено до білінгу та каталогу.');
  }

  async createOrder(dto: CreateOrderDto): Promise<Order> {
    if (!Number.isInteger(dto?.quantity) || dto.quantity < 1) {
      throw new BadRequestException('quantity має бути цілим числом ≥ 1');
    }
    const product = await this.gadgetsService.findOne(dto.productId); // NotFoundException, якщо товару немає
    const unitPrice = Number(product.price); // decimal з PostgreSQL приходить рядком
    const subtotal = unitPrice * dto.quantity;
    const taxAmount = this.fees.calculateTax(subtotal);
    const order: Order = {
      orderId: `ord-${Date.now()}-${this.orders.length + 1}`,
      customerEmail: dto.customerEmail,
      productTitle: product.title,
      productSlug: this.slugService.generateSlug(product.title),
      unitPrice,
      quantity: dto.quantity,
      subtotal,
      taxAmount,
      total: subtotal + taxAmount,
      currency: this.config.defaultCurrency,
      status: OrderStatus.CONFIRMED,
      createdAt: new Date().toISOString(),
    };
    this.orders.push(order);
    await this.notify(order, dto.customerEmail); // підтвердження покупки: кімната + лист
    return order;
  }

  /** Зміна статусу: одночасно WebSocket-сповіщення в кімнату order_<id> та HTML-лист покупцю. */
  async updateStatus(orderId: string, dto: UpdateOrderStatusDto) {
    const order = this.orders.find((o) => o.orderId === orderId);
    if (!order) throw new NotFoundException(`Замовлення ${orderId} не знайдено`);
    order.status = dto.status;
    const mailSent = await this.notify(order, dto.customerEmail ?? order.customerEmail);
    return {
      success: true,
      message: 'Статус замовлення оновлено, сповіщення надіслано в кімнату та на пошту',
      mailSent,
      order,
    };
  }

  private async notify(order: Order, to: string): Promise<boolean> {
    this.events.emitToRoom(`order_${order.orderId}`, 'orderStatusChanged', {
      orderId: order.orderId,
      status: order.status,
      message: statusText(order.status),
      at: new Date().toISOString(),
    });
    const html = orderEmailHtml({
      orderId: order.orderId,
      status: order.status,
      productTitle: order.productTitle,
      quantity: order.quantity,
      total: order.total,
      currency: order.currency,
      trackUrl: `http://localhost:3000/client.html?room=order_${order.orderId}`,
    });
    return this.mail.sendNotificationEmail(to, `Замовлення ${order.orderId}: ${statusText(order.status)}`, html);
  }

  findAll(): Order[] {
    return this.orders;
  }
}
