import { Module } from '@nestjs/common';
import { GadgetsModule } from '../gadgets/gadgets.module.js';
import { NotificationsModule } from '../notifications/notifications.module.js';
import { SharedModule } from '../shared/shared.module.js';
import { OrdersController } from './orders.controller.js';
import { OrdersService } from './orders.service.js';

@Module({
  imports: [GadgetsModule, SharedModule, NotificationsModule],
  controllers: [OrdersController],
  providers: [OrdersService],
})
export class OrdersModule {}
