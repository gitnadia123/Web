import { IsEmail, IsEnum, IsOptional } from 'class-validator';

export enum OrderStatus {
  CONFIRMED = 'CONFIRMED',
  PAID = 'PAID',
  SHIPPED = 'SHIPPED',
  DELIVERED = 'DELIVERED',
  WARRANTY_ACTIVATED = 'WARRANTY_ACTIVATED',
}

export class UpdateOrderStatusDto {
  @IsEnum(OrderStatus, { message: `status має бути одним із: ${Object.values(OrderStatus).join(', ')}` })
  readonly status!: OrderStatus;

  /** Якщо не вказано — береться пошта з самого замовлення. */
  @IsOptional() @IsEmail()
  readonly customerEmail?: string;
}
