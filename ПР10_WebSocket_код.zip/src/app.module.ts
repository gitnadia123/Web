import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HttpLoggingMiddleware } from './common/middleware/http-logger.middleware.js';
import { BrandsModule } from './brands/brands.module.js';
import { GadgetsModule } from './gadgets/gadgets.module.js';
import { NotificationsModule } from './notifications/notifications.module.js';
import { OrdersModule } from './orders/orders.module.js';
import { SharedModule } from './shared/shared.module.js';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST ?? 'localhost',
      port: Number(process.env.DB_PORT ?? 5432),
      username: process.env.DB_USER ?? 'nest_user',
      password: process.env.DB_PASSWORD ?? 'nest_password',
      database: process.env.DB_NAME ?? 'store_db',
      autoLoadEntities: true, // сутності підтягуються з forFeature()
      synchronize: false, // схемою керують міграції (npm run migration:run)
      logging: ['error'],
    }),
    GadgetsModule,
    BrandsModule,
    OrdersModule,
    NotificationsModule,
    SharedModule,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(HttpLoggingMiddleware).forRoutes('*');
  }
}
