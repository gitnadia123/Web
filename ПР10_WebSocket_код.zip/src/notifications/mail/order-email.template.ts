export interface OrderEmailData {
  orderId: string;
  status: string;
  productTitle: string;
  quantity: number;
  total: number;
  currency: string;
  trackUrl: string;
}

const STATUS_TEXT: Record<string, string> = {
  CONFIRMED: 'Покупку підтверджено',
  PAID: 'Оплату отримано',
  SHIPPED: 'Замовлення передано в доставку',
  DELIVERED: 'Замовлення доставлено',
  WARRANTY_ACTIVATED: 'Гарантію активовано',
};

export const statusText = (s: string) => STATUS_TEXT[s] ?? s;

/** Адаптивний HTML-лист (таблична верстка, inline-стилі — сумісна з поштовими клієнтами). */
export function orderEmailHtml(d: OrderEmailData): string {
  const money = new Intl.NumberFormat('uk-UA', { style: 'currency', currency: d.currency }).format(d.total);
  const warranty =
    d.status === 'WARRANTY_ACTIVATED'
      ? `<p style="margin:16px 0 0;padding:12px;background:#ecfdf5;border-radius:8px;color:#065f46;font-size:14px">🛡️ Офіційну гарантію на пристрій активовано. Збережіть цей лист як підтвердження.</p>`
      : '';
  return `<!doctype html>
<html lang="uk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif;color:#111827">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f4f6;padding:24px 12px"><tr><td align="center">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden">
    <tr><td style="background:#1d4ed8;padding:20px 24px;color:#ffffff;font-size:22px;font-weight:bold">⚡ Tech Gadgets Store</td></tr>
    <tr><td style="padding:24px">
      <h1 style="margin:0 0 8px;font-size:20px">${statusText(d.status)}</h1>
      <p style="margin:0 0 20px;color:#4b5563;font-size:14px">Замовлення <b>${d.orderId}</b> змінило статус на <b>${d.status}</b>.</p>
      <table role="presentation" width="100%" cellspacing="0" cellpadding="8" style="border-collapse:collapse;font-size:14px">
        <tr style="background:#f9fafb"><td style="border:1px solid #e5e7eb">Товар</td><td style="border:1px solid #e5e7eb"><b>${d.productTitle}</b></td></tr>
        <tr><td style="border:1px solid #e5e7eb">Кількість</td><td style="border:1px solid #e5e7eb">${d.quantity}</td></tr>
        <tr style="background:#f9fafb"><td style="border:1px solid #e5e7eb">Сума (з ПДВ)</td><td style="border:1px solid #e5e7eb"><b>${money}</b></td></tr>
        <tr><td style="border:1px solid #e5e7eb">Статус</td><td style="border:1px solid #e5e7eb">${d.status}</td></tr>
      </table>
      ${warranty}
      <p style="text-align:center;margin:28px 0 8px"><a href="${d.trackUrl}" style="background:#1d4ed8;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:bold;display:inline-block">Переглянути замовлення</a></p>
    </td></tr>
    <tr><td style="padding:16px 24px;background:#f9fafb;color:#6b7280;font-size:12px;text-align:center">Це автоматичне повідомлення. Tech Gadgets Store · Ужгород</td></tr>
  </table>
</td></tr></table></body></html>`;
}
