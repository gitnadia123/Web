import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private readonly transporter = nodemailer.createTransport({
    host: process.env.MAIL_HOST ?? 'localhost',
    port: Number(process.env.MAIL_PORT ?? 1025),
    secure: false,
    ignoreTLS: true, // локальна SMTP-пастка без TLS
  });

  /** Повертає true, якщо лист прийнято SMTP-сервером; помилка пошти не валить бізнес-операцію. */
  async sendNotificationEmail(to: string, subject: string, htmlContent: string): Promise<boolean> {
    try {
      const info = await this.transporter.sendMail({
        from: '"Tech Gadgets Store" <no-reply@techgadgets.local>',
        to,
        subject,
        html: htmlContent,
      });
      this.logger.log(`Лист успішно надіслано на адресу ${to} (Message ID: ${info.messageId})`);
      return true;
    } catch (err) {
      this.logger.error(`Не вдалося надіслати лист на ${to}: ${(err as Error).message}`);
      return false;
    }
  }
}
