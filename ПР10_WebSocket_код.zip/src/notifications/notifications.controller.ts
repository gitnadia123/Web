import { Controller, MessageEvent, Sse } from '@nestjs/common';
import { interval, map, Observable } from 'rxjs';
import { EventsGateway } from './events.gateway.js';

@Controller('notifications')
export class NotificationsController {
  constructor(private readonly gateway: EventsGateway) {}

  /** Потік системних показників кожні 5 секунд (Server-Sent Events). */
  @Sse('events/stream')
  stream(): Observable<MessageEvent> {
    return interval(5000).pipe(
      map((tick) => ({
        id: String(tick + 1),
        type: 'metrics',
        data: {
          status: 'ok',
          activeConnections: this.gateway.activeConnections,
          uptimeSec: Math.round(process.uptime()),
          serverTime: new Date().toISOString(),
        },
      })),
    );
  }
}
