import { Module } from '@nestjs/common';
import { EventsGateway } from './events.gateway.js';
import { MailService } from './mail/mail.service.js';
import { NotificationsController } from './notifications.controller.js';

@Module({
  controllers: [NotificationsController],
  providers: [EventsGateway, MailService],
  exports: [EventsGateway, MailService],
})
export class NotificationsModule {}
