import { Logger } from '@nestjs/common';
import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({ cors: { origin: '*' } })
export class EventsGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(EventsGateway.name);

  afterInit(): void {
    this.logger.log('EventsGateway initialized');
  }

  handleConnection(client: Socket): void {
    this.logger.log(`Клієнт підключився: ${client.id}`);
  }

  handleDisconnect(client: Socket): void {
    this.logger.log(`Клієнт відключився: ${client.id}`);
  }

  /** Кількість активних сокет-з’єднань (для SSE-метрик). */
  get activeConnections(): number {
    return this.server?.sockets?.sockets?.size ?? 0;
  }

  @SubscribeMessage('ping')
  handlePing(@MessageBody() data: unknown): { event: string; data: { timestamp: string; echo: unknown } } {
    return { event: 'pong', data: { timestamp: new Date().toISOString(), echo: data } };
  }

  /** Широкомовлення: повідомлення отримують усі активні сокети. */
  @SubscribeMessage('broadcastNotification')
  handleBroadcast(@MessageBody() message: string, @ConnectedSocket() client: Socket): void {
    this.logger.log(`Broadcast від ${client.id}: ${message}`);
    this.server.emit('globalAlert', { message, from: client.id, at: new Date().toISOString() });
  }

  @SubscribeMessage('joinRoom')
  async handleJoinRoom(@MessageBody() roomId: string, @ConnectedSocket() client: Socket) {
    await client.join(roomId); // приєднання виконується на сервері
    this.logger.log(`Клієнт ${client.id} приєднався до кімнати: ${roomId}`);
    return { event: 'joinedRoom', data: { roomId } };
  }

  @SubscribeMessage('leaveRoom')
  async handleLeaveRoom(@MessageBody() roomId: string, @ConnectedSocket() client: Socket) {
    await client.leave(roomId);
    this.logger.log(`Клієнт ${client.id} залишив кімнату: ${roomId}`);
    return { event: 'leftRoom', data: { roomId } };
  }

  /** Адресне сповіщення: подію отримують лише сокети з указаної кімнати. */
  emitToRoom(roomId: string, event: string, data: unknown): void {
    this.server.to(roomId).emit(event, data);
    this.logger.log(`Сповіщення надіслано в кімнату ${roomId}: ${JSON.stringify({ event, ...(data as object) })}`);
  }
}
