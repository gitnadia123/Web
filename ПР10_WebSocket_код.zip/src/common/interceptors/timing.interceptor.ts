import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import type { Request, Response } from 'express';
import { Observable, tap } from 'rxjs';

@Injectable()
export class TimingInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    // глобальний interceptor викликається й для WebSocket-обробників, де немає HTTP-відповіді
    if (context.getType() !== 'http') return next.handle();
    const http = context.switchToHttp();
    const req = http.getRequest<Request>();
    const res = http.getResponse<Response>();
    const start = Date.now();
    let measured = false; // для потоків (SSE) tap спрацьовує багаторазово — міряємо лише першу подію
    return next.handle().pipe(
      tap(() => {
        if (measured) return;
        measured = true;
        const ms = Date.now() - start;
        if (!res.headersSent) res.setHeader('X-Response-Time', `${ms}ms`);
        console.log(`[TIMING] Маршрут ${req.method} ${req.originalUrl} виконано за ${ms}ms`);
      }),
    );
  }
}
