# ПР9 — Автентифікація (JWT, bcrypt, Passport) та RBAC (NestJS, варіант 1)
Ролі: ADMIN, STORE_MANAGER, CUSTOMER. Публічно: перегляд товарів і брендів. Створення/редагування/видалення — STORE_MANAGER, ADMIN.

    docker compose up -d
    npm i --legacy-peer-deps
    npm run migration:run
    JWT_SECRET=... JWT_REFRESH_SECRET=... npm run start:prod

Першого адміністратора створюють реєстрацією + `UPDATE users SET role='ADMIN' WHERE email='...'`; далі ролі змінює ADMIN через PATCH /users/:id/role.
Тести: requests.http
