import { MigrationInterface, QueryRunner } from "typeorm";

export class AddFeatures1795174532229 implements MigrationInterface {
    name = 'AddFeatures1795174532229'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "features" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(50) NOT NULL, CONSTRAINT "UQ_bcc3a344ae156a9fba128e1cb4d" UNIQUE ("name"), CONSTRAINT "PK_5c1e336df2f4a7051e5bf08a941" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "gadgets_features_features" ("gadgetsId" uuid NOT NULL, "featuresId" uuid NOT NULL, CONSTRAINT "PK_a9356856e55640275b3521317dd" PRIMARY KEY ("gadgetsId", "featuresId"))`);
        await queryRunner.query(`CREATE INDEX "IDX_8273459d39fce25f71a089511b" ON "gadgets_features_features"  ("gadgetsId") `);
        await queryRunner.query(`CREATE INDEX "IDX_2411b92d6a829ab868b75b25c6" ON "gadgets_features_features"  ("featuresId") `);
        await queryRunner.query(`ALTER TABLE "gadgets_features_features" ADD CONSTRAINT "FK_8273459d39fce25f71a089511b9" FOREIGN KEY ("gadgetsId") REFERENCES "gadgets"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "gadgets_features_features" ADD CONSTRAINT "FK_2411b92d6a829ab868b75b25c63" FOREIGN KEY ("featuresId") REFERENCES "features"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "gadgets_features_features" DROP CONSTRAINT "FK_2411b92d6a829ab868b75b25c63"`);
        await queryRunner.query(`ALTER TABLE "gadgets_features_features" DROP CONSTRAINT "FK_8273459d39fce25f71a089511b9"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_2411b92d6a829ab868b75b25c6"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_8273459d39fce25f71a089511b"`);
        await queryRunner.query(`DROP TABLE "gadgets_features_features"`);
        await queryRunner.query(`DROP TABLE "features"`);
    }

}
