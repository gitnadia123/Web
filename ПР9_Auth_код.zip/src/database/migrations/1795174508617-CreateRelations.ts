import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateRelations1795174508617 implements MigrationInterface {
    name = 'CreateRelations1795174508617'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "gadgets" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "title" character varying(150) NOT NULL, "price" numeric(10,2) NOT NULL, "warrantyMonths" integer NOT NULL, "cpu" character varying(100) NOT NULL, "ramGb" integer NOT NULL, "isAvailable" boolean NOT NULL DEFAULT true, "brandId" uuid, "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP WITH TIME ZONE, CONSTRAINT "PK_cdf8116792b84dececf13ce72aa" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "brands" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(100) NOT NULL, "country" character varying(100), CONSTRAINT "UQ_96db6bbbaa6f23cad26871339b6" UNIQUE ("name"), CONSTRAINT "PK_b0c437120b624da1034a81fc561" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "gadgets" ADD CONSTRAINT "FK_bfd013706dc967494b3d914bba3" FOREIGN KEY ("brandId") REFERENCES "brands"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "gadgets" DROP CONSTRAINT "FK_bfd013706dc967494b3d914bba3"`);
        await queryRunner.query(`DROP TABLE "brands"`);
        await queryRunner.query(`DROP TABLE "gadgets"`);
    }

}
