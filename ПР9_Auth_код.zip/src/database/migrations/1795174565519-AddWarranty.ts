import { MigrationInterface, QueryRunner } from "typeorm";

export class AddWarranty1795174565519 implements MigrationInterface {
    name = 'AddWarranty1795174565519'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "warranties" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "durationMonths" integer NOT NULL, "conditions" text NOT NULL, "gadgetId" uuid NOT NULL, CONSTRAINT "UQ_46beab60de3ecba92e7ebe56994" UNIQUE ("gadgetId"), CONSTRAINT "REL_46beab60de3ecba92e7ebe5699" UNIQUE ("gadgetId"), CONSTRAINT "PK_62c441630f8a6ddcc4bc1ab1bc5" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "warranties" ADD CONSTRAINT "FK_46beab60de3ecba92e7ebe56994" FOREIGN KEY ("gadgetId") REFERENCES "gadgets"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "warranties" DROP CONSTRAINT "FK_46beab60de3ecba92e7ebe56994"`);
        await queryRunner.query(`DROP TABLE "warranties"`);
    }

}
