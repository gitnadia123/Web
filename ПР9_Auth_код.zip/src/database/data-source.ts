import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

/** DataSource для TypeORM CLI (міграції). Використовується з уже зібраного коду (dist). */
export default new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST ?? 'localhost',
  port: Number(process.env.DB_PORT ?? 5432),
  username: process.env.DB_USER ?? 'nest_user',
  password: process.env.DB_PASSWORD ?? 'nest_password',
  database: process.env.DB_NAME ?? 'store_db',
  entities: [join(here, '..', '**', '*.entity.js')],
  migrations: [join(here, 'migrations', '*.js')],
  synchronize: false,
  logging: ['error'],
});
