import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BrandEntity } from '../brands/entities/brand.entity.js';
import { FeatureEntity } from '../features/entities/feature.entity.js';
import { WarrantyEntity } from '../warranties/entities/warranty.entity.js';
import { GadgetsController } from './gadgets.controller.js';
import { GadgetsService } from './gadgets.service.js';
import { GadgetEntity } from './entities/gadget.entity.js';

@Module({
  imports: [TypeOrmModule.forFeature([GadgetEntity, BrandEntity, FeatureEntity, WarrantyEntity])],
  controllers: [GadgetsController],
  providers: [GadgetsService],
  exports: [GadgetsService],
})
export class GadgetsModule {}
