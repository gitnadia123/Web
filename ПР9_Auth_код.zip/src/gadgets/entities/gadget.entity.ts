import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { WarrantyEntity } from '../../warranties/entities/warranty.entity.js';
import { FeatureEntity } from '../../features/entities/feature.entity.js';
import { BrandEntity } from '../../brands/entities/brand.entity.js';

@Entity('gadgets')
export class GadgetEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'varchar', length: 150 })
  title!: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price!: number;

  @Column({ type: 'integer' })
  warrantyMonths!: number;

  @Column({ type: 'varchar', length: 100 })
  cpu!: string;

  @Column({ type: 'integer' })
  ramGb!: number;

  @Column({ type: 'boolean', default: true })
  isAvailable!: boolean;

  @Column({ type: 'uuid', nullable: true })
  brandId!: string | null;

  // M:1 — багато гаджетів належать одному бренду; при видаленні бренду brandId стає NULL
  @ManyToOne(() => BrandEntity, (brand) => brand.gadgets, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'brandId' })
  brand!: BrandEntity | null;

  // M:N — проміжна таблиця gadgets_features_features; cascade зберігає нові фічі разом із гаджетом
  @ManyToMany(() => FeatureEntity, (feature) => feature.gadgets, { cascade: true })
  @JoinTable()
  features!: FeatureEntity[];

  // 1:1 — розширені гарантійні умови (зворотний бік зв’язку; FK лежить у warranties)
  @OneToOne(() => WarrantyEntity, (warranty) => warranty.gadget, { cascade: true })
  warranty!: WarrantyEntity | null;

  @CreateDateColumn({ type: 'timestamp with time zone' })
  createdAt!: Date;

  @UpdateDateColumn({ type: 'timestamp with time zone' })
  updatedAt!: Date;

  @DeleteDateColumn({ type: 'timestamp with time zone', nullable: true })
  deletedAt!: Date | null;
}
