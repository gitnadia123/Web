import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { DataSource, EntityManager, In, Repository } from 'typeorm';
import { BrandEntity } from '../brands/entities/brand.entity.js';
import { FeatureEntity } from '../features/entities/feature.entity.js';
import { WarrantyEntity } from '../warranties/entities/warranty.entity.js';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { PaginationQueryDto } from './dto/pagination-query.dto.js';
import { TransactionalGadgetDto } from './dto/transactional-gadget.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import { GadgetEntity } from './entities/gadget.entity.js';

@Injectable()
export class GadgetsService {
  constructor(
    @InjectRepository(GadgetEntity) private readonly gadgetRepo: Repository<GadgetEntity>,
    @InjectRepository(BrandEntity) private readonly brandRepo: Repository<BrandEntity>,
    @InjectDataSource() private readonly dataSource: DataSource,
  ) {}

  /** Знаходить фічі за назвами, відсутні створює в пам’яті (збережуться через cascade). */
  private async resolveFeatures(names: string[], manager: EntityManager): Promise<FeatureEntity[]> {
    const unique = [...new Set(names)];
    const existing = await manager.find(FeatureEntity, { where: { name: In(unique) } });
    const known = new Set(existing.map((f) => f.name));
    const fresh = unique.filter((n) => !known.has(n)).map((name) => manager.create(FeatureEntity, { name }));
    return [...existing, ...fresh];
  }

  async create(dto: CreateGadgetDto): Promise<GadgetEntity> {
    const { features, ...rest } = dto;
    if (rest.brandId && !(await this.brandRepo.existsBy({ id: rest.brandId }))) {
      throw new NotFoundException(`Бренд з ID ${rest.brandId} не знайдено`);
    }
    const gadget = this.gadgetRepo.create(rest);
    if (features) gadget.features = await this.resolveFeatures(features, this.gadgetRepo.manager); // cascade збереже нові фічі
    return this.gadgetRepo.save(gadget);
  }

  /** Список із пагінацією, пошуком і фільтрами за брендом / фічею (QueryBuilder). */
  async findAll(query: PaginationQueryDto) {
    const { page, limit, search, sortBy, order, feature, brand } = query;
    const qb = this.gadgetRepo.createQueryBuilder('g').leftJoinAndSelect('g.brand', 'brand');
    if (feature) {
      qb.innerJoinAndSelect('g.features', 'feature').where('feature.name ILIKE :feature', { feature });
    } else {
      qb.leftJoinAndSelect('g.features', 'feature');
    }
    if (brand) qb.andWhere('brand.name ILIKE :brand', { brand });
    if (search) qb.andWhere('g.title ILIKE :search', { search: `%${search}%` });
    qb.orderBy(`g.${sortBy}`, order).skip((page - 1) * limit).take(limit);
    const [data, total] = await qb.getManyAndCount();
    return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  async findOne(id: string): Promise<GadgetEntity> {
    const gadget = await this.gadgetRepo.findOne({ where: { id }, relations: { brand: true } });
    if (!gadget) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    return gadget;
  }

  /** Повний агрегат: одним QueryBuilder-запитом підвантажуються 1:M (brand), M:N (features) та 1:1 (warranty). */
  async findFull(id: string): Promise<GadgetEntity> {
    const gadget = await this.gadgetRepo
      .createQueryBuilder('g')
      .leftJoinAndSelect('g.brand', 'brand')
      .leftJoinAndSelect('g.features', 'feature')
      .leftJoinAndSelect('g.warranty', 'warranty')
      .where('g.id = :id', { id })
      .getOne();
    if (!gadget) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    return gadget;
  }

  async update(id: string, dto: UpdateGadgetDto): Promise<GadgetEntity> {
    const gadget = await this.findOne(id);
    const { features, ...rest } = dto;
    Object.assign(gadget, Object.fromEntries(Object.entries(rest).filter(([, v]) => v !== undefined)));
    if (features) gadget.features = await this.resolveFeatures(features, this.gadgetRepo.manager);
    await this.gadgetRepo.save(gadget);
    return this.findFull(id);
  }

  async remove(id: string): Promise<void> {
    await this.findOne(id);
    await this.gadgetRepo.softDelete(id);
  }

  async restore(id: string): Promise<GadgetEntity> {
    const res = await this.gadgetRepo.restore(id);
    if (!res.affected) throw new NotFoundException(`Сутність з ID ${id} не знайдена`);
    return this.findOne(id);
  }

  /**
   * Атомарне створення агрегата (бренд + гаджет + фічі + гарантія) в одній транзакції.
   * Якщо будь-який крок кидає виняток — відкочуються ВСІ зміни.
   */
  async createTransactional(dto: TransactionalGadgetDto): Promise<GadgetEntity> {
    const id = await this.dataSource.transaction(async (manager) => {
      let brand: BrandEntity | null = null;
      if (dto.brandName) {
        brand = (await manager.findOneBy(BrandEntity, { name: dto.brandName })) ?? (await manager.save(manager.create(BrandEntity, { name: dto.brandName })));
      }
      const gadget = manager.create(GadgetEntity, {
        title: dto.title,
        price: dto.price,
        cpu: dto.cpu ?? 'n/a',
        ramGb: dto.ramGb ?? 2,
        warrantyMonths: dto.warranty?.durationMonths ?? 12,
        brandId: brand?.id ?? null,
        features: dto.features ? await this.resolveFeatures(dto.features, manager) : [],
      });
      await manager.save(gadget); // бренд, гаджет і фічі вже записані в межах транзакції
      if (dto.warranty) {
        await manager.save(manager.create(WarrantyEntity, { ...dto.warranty, gadgetId: gadget.id }));
      }
      // бізнес-перевірка ПІСЛЯ часткового збереження: за помилки транзакція відкотить усе
      if (dto.price < 0) throw new BadRequestException("Ціна не може бути від'ємною. Транзакцію відкочено.");
      return gadget.id;
    });
    return this.findFull(id);
  }
}
