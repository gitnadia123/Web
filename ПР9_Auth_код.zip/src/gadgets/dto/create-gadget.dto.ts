import { IsArray, IsBoolean, IsUUID, IsInt, IsNotEmpty, IsOptional, IsNumber, IsPositive, IsString, Max, Min } from 'class-validator';

export class CreateGadgetDto {
  @IsString({ message: 'title має бути рядком' })
  @IsNotEmpty({ message: 'title не може бути порожнім' })
  readonly title!: string;

  @IsNumber({}, { message: 'price має бути числом' })
  @IsPositive({ message: 'price має бути більше 0' })
  readonly price!: number;

  @Min(1, { message: 'warrantyMonths має бути не менше 1' })
  @Max(60, { message: 'warrantyMonths має бути не більше 60' })
  @IsInt({ message: 'warrantyMonths має бути цілим числом' })
  readonly warrantyMonths!: number;

  @IsString({ message: 'cpu має бути рядком' })
  @IsNotEmpty({ message: 'cpu не може бути порожнім' })
  readonly cpu!: string;

  @Min(2, { message: 'ramGb має бути не менше 2' })
  @IsInt({ message: 'ramGb має бути цілим числом' })
  readonly ramGb!: number;

  @IsOptional() @IsBoolean({ message: 'isAvailable має бути boolean' })
  readonly isAvailable?: boolean;

  @IsOptional() @IsUUID()
  readonly brandId?: string;

  @IsOptional() @IsArray() @IsString({ each: true })
  readonly features?: string[];
}
