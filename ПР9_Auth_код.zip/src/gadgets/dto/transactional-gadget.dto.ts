import { Type } from 'class-transformer';
import { IsArray, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Min, ValidateNested } from 'class-validator';

export class WarrantyInputDto {
  @IsInt() @Min(1)
  readonly durationMonths!: number;

  @IsString() @IsNotEmpty()
  readonly conditions!: string;
}

/**
 * DTO для транзакційного створення агрегата. Знак ціни навмисно перевіряється
 * не декоратором, а бізнес-логікою всередині транзакції (щоб показати rollback).
 */
export class TransactionalGadgetDto {
  @IsString() @IsNotEmpty()
  readonly title!: string;

  @IsNumber()
  readonly price!: number;

  @IsOptional() @IsString() readonly cpu?: string;
  @IsOptional() @IsInt() readonly ramGb?: number;
  @IsOptional() @IsString() readonly brandName?: string;

  @IsOptional() @IsArray() @IsString({ each: true })
  readonly features?: string[];

  @IsOptional() @ValidateNested() @Type(() => WarrantyInputDto)
  readonly warranty?: WarrantyInputDto;
}
