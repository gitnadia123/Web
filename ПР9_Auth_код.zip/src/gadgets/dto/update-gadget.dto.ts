import { IsArray, IsBoolean, IsUUID, IsInt, IsNotEmpty, IsNumber, IsOptional, IsPositive, IsString, Max, Min } from 'class-validator';

export class UpdateGadgetDto {
  @IsOptional() @IsString() @IsNotEmpty()
  readonly title?: string;

  @IsOptional() @IsNumber() @IsPositive()
  readonly price?: number;

  @IsOptional() @IsInt() @Min(1) @Max(60)
  readonly warrantyMonths?: number;

  @IsOptional() @IsString() @IsNotEmpty()
  readonly cpu?: string;

  @IsOptional() @IsInt() @Min(2)
  readonly ramGb?: number;

  @IsOptional() @IsBoolean({ message: 'isAvailable має бути boolean' })
  readonly isAvailable?: boolean;

  @IsOptional() @IsUUID()
  readonly brandId?: string;

  @IsOptional() @IsArray() @IsString({ each: true })
  readonly features?: string[];
}
