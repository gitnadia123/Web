import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { Public } from '../common/decorators/public.decorator.js';
import { Roles } from '../common/decorators/roles.decorator.js';
import { Role } from '../users/role.enum.js';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { PaginationQueryDto } from './dto/pagination-query.dto.js';
import { TransactionalGadgetDto } from './dto/transactional-gadget.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import { GadgetsService } from './gadgets.service.js';

@Controller('gadgets')
export class GadgetsController {
  constructor(private readonly gadgetsService: GadgetsService) {}

  @Public()
  @Get()
  findAll(@Query() query: PaginationQueryDto) {
    return this.gadgetsService.findAll(query);
  }

  @Public()
  @Get(':id/full')
  findFull(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.findFull(id);
  }

  @Public()
  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.findOne(id);
  }

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Post()
  @HttpCode(HttpStatus.CREATED)
  create(@Body() dto: CreateGadgetDto) {
    return this.gadgetsService.create(dto);
  }

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Post('transactional')
  @HttpCode(HttpStatus.CREATED)
  createTransactional(@Body() dto: TransactionalGadgetDto) {
    return this.gadgetsService.createTransactional(dto);
  }

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Patch(':id/restore')
  restore(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.restore(id);
  }

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Patch(':id')
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateGadgetDto) {
    return this.gadgetsService.update(id, dto);
  }

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.gadgetsService.remove(id);
  }
}
