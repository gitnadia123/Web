import { Injectable } from '@nestjs/common';

const UA_TO_LAT: Record<string, string> = {
  а: 'a', б: 'b', в: 'v', г: 'h', ґ: 'g', д: 'd', е: 'e', є: 'ie', ж: 'zh', з: 'z', и: 'y', і: 'i',
  ї: 'i', й: 'i', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u',
  ф: 'f', х: 'kh', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'shch', ь: '', ю: 'iu', я: 'ia',
  ъ: '', ы: 'y', э: 'e', ё: 'io',
};

@Injectable()
export class SlugService {
  /** "Pro Laptop 16" -> "pro-laptop-16"; кирилицю транслітерує. */
  generateSlug(title: string): string {
    return title
      .toLowerCase()
      .split('')
      .map((ch) => UA_TO_LAT[ch] ?? ch)
      .join('')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }
}
