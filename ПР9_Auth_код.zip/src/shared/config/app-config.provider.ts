import type { Provider } from '@nestjs/common';

// Токен ін’єкції та контракт конфігурації
export const STORE_CONFIG = 'STORE_CONFIG';

export interface StoreConfig {
  storeName: string;
  defaultCurrency: string;
  taxPercent: number;
}

// Custom Provider за стратегією useValue
export const StoreConfigProvider: Provider = {
  provide: STORE_CONFIG,
  useValue: {
    storeName: 'Tech Gadgets Store',
    defaultCurrency: 'UAH',
    taxPercent: 20,
  } satisfies StoreConfig,
};
