import type { Provider } from '@nestjs/common';
import { STORE_CONFIG } from './app-config.provider.js';
import type { StoreConfig } from './app-config.provider.js';

export const FEE_CALCULATOR = 'FEE_CALCULATOR';

export interface FeeCalculator {
  calculateTax(amount: number): number;
}

// Custom Provider за стратегією useFactory: залежить від STORE_CONFIG (масив inject)
export const FeeCalculatorProvider: Provider = {
  provide: FEE_CALCULATOR,
  useFactory: (config: StoreConfig): FeeCalculator => ({
    calculateTax: (amount: number) => Math.round(amount * config.taxPercent) / 100,
  }),
  inject: [STORE_CONFIG],
};
