import { IsEmail, IsInt, IsString, IsUUID, Min } from 'class-validator';

export class CreateOrderDto {
  @IsUUID() readonly productId!: string;
  @IsInt() @Min(1) readonly quantity!: number;
  @IsEmail() readonly customerEmail!: string;
}
