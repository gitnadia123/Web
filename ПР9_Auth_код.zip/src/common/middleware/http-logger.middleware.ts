import { Injectable, Logger, NestMiddleware } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';

@Injectable()
export class HttpLoggingMiddleware implements NestMiddleware {
  private readonly logger = new Logger('HttpLoggingMiddleware');

  use(req: Request, res: Response, next: NextFunction): void {
    const start = Date.now();
    const { method, originalUrl, ip } = req;
    res.on('finish', () => {
      this.logger.log(`[HTTP] ${method} ${originalUrl} ${res.statusCode} +${Date.now() - start}ms (${ip})`);
    });
    next();
  }
}
