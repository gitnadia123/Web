import { Injectable, PipeTransform } from '@nestjs/common';

/** Рекурсивно обрізає пробіли у всіх рядках тіла запиту. */
@Injectable()
export class TrimPipe implements PipeTransform {
  transform(value: unknown): unknown {
    return this.trim(value);
  }

  private trim(v: unknown): unknown {
    if (typeof v === 'string') return v.trim();
    if (Array.isArray(v)) return v.map((x) => this.trim(x));
    if (v !== null && typeof v === 'object') {
      return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, this.trim(x)]));
    }
    return v;
  }
}
