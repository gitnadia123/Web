import { ArgumentsHost, Catch, ExceptionFilter, HttpException } from '@nestjs/common';
import type { Request, Response } from 'express';

@Catch(HttpException)
export class GlobalExceptionFilter implements ExceptionFilter {
  catch(exception: HttpException, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const req = ctx.getRequest<Request>();
    const res = ctx.getResponse<Response>();
    const status = exception.getStatus();
    const body = exception.getResponse();
    const raw = typeof body === 'string' ? body : (body as any).message;
    const message: string[] = Array.isArray(raw) ? raw : [String(raw)];
    const error = typeof body === 'object' && (body as any).error ? (body as any).error : exception.name;
    res.status(status).json({
      success: false,
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: req.originalUrl,
      method: req.method,
      error,
      message,
    });
  }
}
