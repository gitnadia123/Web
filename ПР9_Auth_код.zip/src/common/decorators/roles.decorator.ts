import { SetMetadata } from '@nestjs/common';
import { Role } from '../../users/role.enum.js';

export const ROLES_KEY = 'roles';
/** Записує дозволені ролі у метадані обробника. */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);
