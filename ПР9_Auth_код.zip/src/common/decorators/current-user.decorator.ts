import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { Request } from 'express';
import type { AuthUser } from '../../auth/strategies/jwt.strategy.js';

/** @CurrentUser() — весь користувач із req.user, @CurrentUser('id') — окреме поле. */
export const CurrentUser = createParamDecorator((field: keyof AuthUser | undefined, ctx: ExecutionContext) => {
  const user = ctx.switchToHttp().getRequest<Request & { user: AuthUser }>().user;
  return field ? user?.[field] : user;
});
