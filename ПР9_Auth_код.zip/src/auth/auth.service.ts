import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { createHash, randomUUID } from 'node:crypto';
import { UserEntity } from '../users/entities/user.entity.js';
import { toPublicUser, UsersService } from '../users/users.service.js';
import { ACCESS_TTL, JWT_REFRESH_SECRET, JWT_SECRET, REFRESH_TTL } from './auth.constants.js';
import type { LoginDto } from './dto/login.dto.js';
import type { RegisterDto } from './dto/register.dto.js';
import type { JwtPayload } from './strategies/jwt.strategy.js';

export interface TokenPair { accessToken: string; refreshToken: string }

const SALT_ROUNDS = 10;
/**
 * bcrypt враховує лише перші 72 байти вхідного рядка, а перші байти JWT (заголовок + початок
 * payload) майже однакові для всіх токенів користувача. Тому токен спершу стискається SHA-256,
 * і вже цей дайджест хешується bcrypt — інакше старий refresh-токен міг би пройти перевірку.
 */
const digest = (token: string) => createHash('sha256').update(token).digest('hex');

@Injectable()
export class AuthService {
  constructor(
    private readonly users: UsersService,
    private readonly jwt: JwtService,
  ) {}

  async register(dto: RegisterDto) {
    if (await this.users.findByEmail(dto.email)) throw new ConflictException('Користувач з такою поштою вже існує');
    const passwordHash = await bcrypt.hash(dto.password, SALT_ROUNDS);
    return toPublicUser(await this.users.create(dto.email, passwordHash)); // роль за замовчуванням — CUSTOMER
  }

  async login(dto: LoginDto): Promise<TokenPair> {
    const user = await this.users.findByEmail(dto.email);
    // однакова помилка для «немає користувача» і «невірний пароль» — щоб не розкривати наявність email
    if (!user || !(await bcrypt.compare(dto.password, user.passwordHash))) {
      throw new UnauthorizedException('Невірні облікові дані');
    }
    return this.issueTokens(user);
  }

  async refresh(refreshToken: string | undefined): Promise<TokenPair> {
    if (!refreshToken) throw new UnauthorizedException('Refresh-токен відсутній');
    let payload: JwtPayload;
    try {
      payload = await this.jwt.verifyAsync<JwtPayload>(refreshToken, { secret: JWT_REFRESH_SECRET });
    } catch {
      throw new UnauthorizedException('Refresh-токен недійсний або прострочений');
    }
    const user = await this.users.findById(payload.sub);
    if (!user?.hashedRefreshToken || !(await bcrypt.compare(digest(refreshToken), user.hashedRefreshToken))) {
      throw new UnauthorizedException('Сесію завершено або токен уже використано');
    }
    return this.issueTokens(user); // ротація: новий хеш у БД робить попередній токен непридатним
  }

  async logout(userId: string): Promise<void> {
    await this.users.setRefreshHash(userId, null);
  }

  private async issueTokens(user: UserEntity): Promise<TokenPair> {
    const payload: JwtPayload = { sub: user.id, email: user.email, role: user.role };
    const [accessToken, refreshToken] = await Promise.all([
      this.jwt.signAsync(payload, { secret: JWT_SECRET, expiresIn: ACCESS_TTL }),
      // jti робить кожен refresh-токен унікальним навіть у межах однієї секунди
      this.jwt.signAsync(payload, { secret: JWT_REFRESH_SECRET, expiresIn: REFRESH_TTL, jwtid: randomUUID() }),
    ]);
    await this.users.setRefreshHash(user.id, await bcrypt.hash(digest(refreshToken), SALT_ROUNDS));
    return { accessToken, refreshToken };
  }
}
