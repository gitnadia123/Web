import { IsEmail, IsString, MinLength } from 'class-validator';

export class RegisterDto {
  @IsEmail({}, { message: 'Некоректна електронна пошта' })
  readonly email!: string;

  @IsString()
  @MinLength(6, { message: 'Пароль має містити щонайменше 6 символів' })
  readonly password!: string;
}
