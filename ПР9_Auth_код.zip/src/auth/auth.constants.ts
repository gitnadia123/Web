export const JWT_SECRET = process.env.JWT_SECRET ?? 'dev-access-secret-change-me';
export const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET ?? 'dev-refresh-secret-change-me';
export const ACCESS_TTL = '15m';
export const REFRESH_TTL = '7d';
export const REFRESH_COOKIE = 'refreshToken';
export const REFRESH_COOKIE_MAX_AGE = 7 * 24 * 60 * 60 * 1000;
