import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, type Relation } from 'typeorm';
import { GadgetEntity } from '../../gadgets/entities/gadget.entity.js';

@Entity('warranties')
export class WarrantyEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'integer' })
  durationMonths!: number;

  @Column({ type: 'text' })
  conditions!: string;

  // 1:1 — власник зв’язку (FK gadgetId у цій таблиці); при видаленні гаджета гарантія видаляється каскадно
  @OneToOne(() => GadgetEntity, (gadget) => gadget.warranty, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'gadgetId' })
  gadget!: Relation<GadgetEntity>; // Relation<> уникає циклічної ініціалізації в ESM

  @Column({ type: 'uuid', unique: true })
  gadgetId!: string;
}
