import { Body, Controller, Get, Param, ParseUUIDPipe, Patch } from '@nestjs/common';
import { Roles } from '../common/decorators/roles.decorator.js';
import { UpdateRoleDto } from './dto/update-role.dto.js';
import { Role } from './role.enum.js';
import { UsersService } from './users.service.js';

@Controller('users')
@Roles(Role.ADMIN)
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get()
  findAll() { return this.users.findAll(); }

  @Patch(':id/role')
  setRole(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateRoleDto) {
    return this.users.setRole(id, dto.role);
  }
}
