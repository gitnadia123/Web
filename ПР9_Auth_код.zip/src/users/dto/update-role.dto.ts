import { IsEnum } from 'class-validator';
import { Role } from '../role.enum.js';

export class UpdateRoleDto {
  @IsEnum(Role, { message: 'role має бути одним із: ADMIN, STORE_MANAGER, CUSTOMER' })
  readonly role!: Role;
}
