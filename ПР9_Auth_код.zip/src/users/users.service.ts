import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity } from './entities/user.entity.js';
import { Role } from './role.enum.js';

/** Безпечне представлення користувача (без passwordHash і hashedRefreshToken). */
export type PublicUser = Pick<UserEntity, 'id' | 'email' | 'role' | 'createdAt'>;

export const toPublicUser = (u: UserEntity): PublicUser => ({ id: u.id, email: u.email, role: u.role, createdAt: u.createdAt });

@Injectable()
export class UsersService {
  constructor(@InjectRepository(UserEntity) private readonly repo: Repository<UserEntity>) {}

  create(email: string, passwordHash: string, role = Role.CUSTOMER): Promise<UserEntity> {
    return this.repo.save(this.repo.create({ email, passwordHash, role }));
  }

  findByEmail(email: string): Promise<UserEntity | null> {
    return this.repo.findOneBy({ email });
  }

  findById(id: string): Promise<UserEntity | null> {
    return this.repo.findOneBy({ id });
  }

  async findAll(): Promise<PublicUser[]> {
    return (await this.repo.find({ order: { createdAt: 'ASC' } })).map(toPublicUser);
  }

  async setRefreshHash(id: string, hash: string | null): Promise<void> {
    await this.repo.update(id, { hashedRefreshToken: hash });
  }

  async setRole(id: string, role: Role): Promise<PublicUser> {
    const user = await this.findById(id);
    if (!user) throw new NotFoundException(`Користувача ${id} не знайдено`);
    user.role = role;
    return toPublicUser(await this.repo.save(user));
  }
}
