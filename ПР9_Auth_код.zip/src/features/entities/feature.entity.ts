import { Column, Entity, ManyToMany, PrimaryGeneratedColumn } from 'typeorm';
import { GadgetEntity } from '../../gadgets/entities/gadget.entity.js';

@Entity('features')
export class FeatureEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'varchar', length: 50, unique: true })
  name!: string;

  @ManyToMany(() => GadgetEntity, (gadget) => gadget.features)
  gadgets!: GadgetEntity[];
}
