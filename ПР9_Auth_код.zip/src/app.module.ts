import { APP_GUARD } from '@nestjs/core';
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HttpLoggingMiddleware } from './common/middleware/http-logger.middleware.js';
import { AuthModule } from './auth/auth.module.js';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard.js';
import { RolesGuard } from './common/guards/roles.guard.js';
import { UsersModule } from './users/users.module.js';
import { BrandsModule } from './brands/brands.module.js';
import { GadgetsModule } from './gadgets/gadgets.module.js';
import { OrdersModule } from './orders/orders.module.js';
import { SharedModule } from './shared/shared.module.js';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST ?? 'localhost',
      port: Number(process.env.DB_PORT ?? 5432),
      username: process.env.DB_USER ?? 'nest_user',
      password: process.env.DB_PASSWORD ?? 'nest_password',
      database: process.env.DB_NAME ?? 'store_db',
      autoLoadEntities: true, // сутності підтягуються з forFeature()
      synchronize: false, // схемою керують міграції (npm run migration:run)
      logging: ['error'],
    }),
    GadgetsModule,
    BrandsModule,
    OrdersModule,
    SharedModule,
    UsersModule,
    AuthModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard }, // 1) автентифікація для всіх маршрутів, крім @Public()
    { provide: APP_GUARD, useClass: RolesGuard }, // 2) авторизація за ролями (@Roles())
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(HttpLoggingMiddleware).forRoutes('*');
  }
}
