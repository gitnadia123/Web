import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { GadgetEntity } from '../../gadgets/entities/gadget.entity.js';

@Entity('brands')
export class BrandEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'varchar', length: 100, unique: true })
  name!: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  country!: string | null;

  // 1:M — один бренд має багато гаджетів
  @OneToMany(() => GadgetEntity, (gadget) => gadget.brand)
  gadgets!: GadgetEntity[];
}
