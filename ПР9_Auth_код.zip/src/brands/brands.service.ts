import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateBrandDto } from './dto/create-brand.dto.js';
import { BrandEntity } from './entities/brand.entity.js';

@Injectable()
export class BrandsService {
  constructor(@InjectRepository(BrandEntity) private readonly repo: Repository<BrandEntity>) {}

  async create(dto: CreateBrandDto): Promise<BrandEntity> {
    if (await this.repo.existsBy({ name: dto.name })) throw new ConflictException(`Бренд «${dto.name}» уже існує`);
    return this.repo.save(this.repo.create(dto));
  }

  findAll() {
    // кількість гаджетів бренду рахується одним запитом із LEFT JOIN та GROUP BY
    return this.repo
      .createQueryBuilder('b')
      .leftJoin('b.gadgets', 'g')
      .select(['b.id AS id', 'b.name AS name', 'b.country AS country'])
      .addSelect('COUNT(g.id)::int', 'gadgetsCount')
      .groupBy('b.id')
      .orderBy('b.name')
      .getRawMany();
  }

  async findOne(id: string): Promise<BrandEntity> {
    const brand = await this.repo.findOne({ where: { id }, relations: { gadgets: true } });
    if (!brand) throw new NotFoundException(`Бренд з ID ${id} не знайдено`);
    return brand;
  }

  /** Фізичне видалення бренду: у гаджетів brandId стає NULL (onDelete: SET NULL). */
  async remove(id: string): Promise<void> {
    const res = await this.repo.delete(id);
    if (!res.affected) throw new NotFoundException(`Бренд з ID ${id} не знайдено`);
  }
}
