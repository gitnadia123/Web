import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateBrandDto {
  @IsString() @IsNotEmpty() @MaxLength(100)
  readonly name!: string;

  @IsOptional() @IsString() @MaxLength(100)
  readonly country?: string;
}
