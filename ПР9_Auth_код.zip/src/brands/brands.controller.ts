import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, ParseUUIDPipe, Post } from '@nestjs/common';
import { Public } from '../common/decorators/public.decorator.js';
import { Roles } from '../common/decorators/roles.decorator.js';
import { Role } from '../users/role.enum.js';
import { BrandsService } from './brands.service.js';
import { CreateBrandDto } from './dto/create-brand.dto.js';

@Controller('brands')
export class BrandsController {
  constructor(private readonly brands: BrandsService) {}

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Post() @HttpCode(HttpStatus.CREATED)
  create(@Body() dto: CreateBrandDto) { return this.brands.create(dto); }

  @Public()
  @Get()
  findAll() { return this.brands.findAll(); }

  @Public()
  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) { return this.brands.findOne(id); }

  @Roles(Role.STORE_MANAGER, Role.ADMIN)
  @Delete(':id') @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string) { return this.brands.remove(id); }
}
