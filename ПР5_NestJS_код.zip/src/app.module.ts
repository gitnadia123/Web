import { Module } from '@nestjs/common';
import { GadgetsModule } from './gadgets/gadgets.module.js';
import { OrdersModule } from './orders/orders.module.js';
import { SharedModule } from './shared/shared.module.js';

@Module({
  imports: [GadgetsModule, OrdersModule, SharedModule],
})
export class AppModule {}
