import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post } from '@nestjs/common';
import { RequestIdService } from '../shared/request-id/request-id.service.js';
import { CreateGadgetDto } from './dto/create-gadget.dto.js';
import { UpdateGadgetDto } from './dto/update-gadget.dto.js';
import { GadgetsService } from './gadgets.service.js';

@Controller('gadgets')
export class GadgetsController {
  constructor(
    private readonly gadgetsService: GadgetsService,
    private readonly requestId: RequestIdService, // Scope.REQUEST: контролер теж стає request-scoped
  ) {}

  @Get()
  findAll() {
    return this.gadgetsService.findAll();
  }

  // Експеримент зі Scope: id запиту та кількість створених екземплярів
  @Get('meta/request-id')
  requestInfo() {
    return { requestId: this.requestId.requestId, instanceNumber: this.requestId.instanceNumber, totalInstancesCreated: RequestIdService.totalCreated };
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.gadgetsService.findOne(id);
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  create(@Body() dto: CreateGadgetDto) {
    return this.gadgetsService.create(dto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateGadgetDto) {
    return this.gadgetsService.update(id, dto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: string): void {
    this.gadgetsService.remove(id);
  }
}
