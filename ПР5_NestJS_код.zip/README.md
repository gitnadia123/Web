# online-store — модульна архітектура NestJS (ПР5, варіант 1)
Модулі: `GadgetsModule` (каталог), `OrdersModule` (замовлення), `SharedModule` (SlugService, STORE_CONFIG [useValue], FEE_CALCULATOR [useFactory], RequestIdService [Scope.REQUEST]).
```bash
npm install --legacy-peer-deps
npm run start:dev      # http://localhost:3000, запити: requests.http
```
